package com.ygw.agora.common;


import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 
 * <p>Title: HttpClientUtils </p>
 * <p>Description: 类描述</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zlp
 * @date 2019年10月25日 下午1:59
 * @version 1.0
 * <p>修改人:zlp </p>
 * <p>修改时间:2019年10月25日 下午1:59</p>
 * <p>修改备注:</p>
 */
public class HttpClientUtils {

    private static final Logger log = LoggerFactory.getLogger(HttpClientUtils.class);

    /** 
     * sendPost: post
     * @param url
     * @param map
     * @param encoding         
     * @return java.lang.String
     * @exception	
     * @author zane
     * @date 2019年06月28日 10:39	 
     */
    public static String sendPost(String url, Map<String, String> map, String encoding) {
        String result = "";
        try {
            // 创建httpclient对象
            CloseableHttpClient httpClient = HttpClients.createDefault();
            // 创建post方式请求对象
            HttpPost httpPost = new HttpPost(url);
            // 装填参数
            List<NameValuePair> nameValuePairs = new ArrayList<>();
            if (map != null) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }
            }
            // 设置参数到请求对象中
            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, encoding));
            // 设置header信息
            // 指定报文头【Content-type】、【User-Agent】
            httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");
            httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
            // 执行请求操作，并拿到结果（同步阻塞）
            CloseableHttpResponse response = httpClient.execute(httpPost);
            // 获取结果实体
            // 判断网络连接状态码是否正常(0--200都数正常)
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), "utf-8");
            }
            // 释放链接
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    /** 
     * sendPost:一句话描述方法功能
     * @param url
     * @param map         
     * @return java.lang.String
     * @exception	
     * @author zane
     * @date 2019年06月28日 10:41	 
     */
    public static String sendPost(String url, Map<String, String> map) {
        return sendPost(url, map, "utf-8");
    }

    /** 
     * sendPost:一句话描述方法功能
     * @param url         
     * @return java.lang.String
     * @exception	
     * @author zane
     * @date 2019年06月28日 10:41	 
     */
    public static String sendPost(String url) {
        return sendPost(url, new HashMap<>(), "utf-8");
    }

    /** 
     * sendPost:一句话描述方法功能
     * @param url
     * @param json
     * @param encoding         
     * @return java.lang.String
     * @exception	
     * @author zane
     * @date 2019年06月28日 10:41	 
     */
    public static String sendPost(String url, String json, String encoding) throws IOException {
        String result = "";
        // 创建httpclient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置参数到请求对象中
        StringEntity stringEntity = new StringEntity(json, ContentType.APPLICATION_JSON);
        stringEntity.setContentEncoding(encoding);
        httpPost.setEntity(stringEntity);
        // 执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = httpClient.execute(httpPost);
        // 获取结果实体
        // 判断网络连接状态码是否正常(0--200都数正常)
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            result = EntityUtils.toString(response.getEntity(), "utf-8");
        }
        // 释放链接
        response.close();
        return result;
    }

    private static void close(CloseableHttpClient closeableHttpClient){
        if(closeableHttpClient!=null){
            try {
                closeableHttpClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void close(CloseableHttpResponse closeableHttpResponse){
        if(closeableHttpResponse!=null){
            try {
                closeableHttpResponse.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /** 
     * sendGetData:一句话描述方法功能
     * @param url
     * @param encoding         
     * @return java.lang.String
     * @exception	
     * @author zane
     * @date 2019年06月28日 10:42	 
     */
    public static String sendGetData(String url, String encoding)  {
        String result = "";
        // 创建httpclient对象
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = HttpClients.createDefault();
            // 创建get方式请求对象
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader("Content-type", "application/json");
            // 通过请求对象获取响应对象
            response = httpClient.execute(httpGet);
            // 获取结果实体
            // 判断网络连接状态码是否正常(0--200都数正常)
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        }catch (IOException e){

        }
        finally {
            close(httpClient);
            close(response);
        }
        return result;
    }


    /**
     * <p>Title: HttpClientUtils </p>
     * <p>Description: sendPostJsonWithBasicAuth</p>
     * <p>Copyright (c) 2019 </p>
     * <p>Company: 上海阳光喔科技有限公司</p>
     * @author zane
     * @date 2019年06月28日 10:54
     * @version 1.0
     * <p>修改人：zane </p>
     * <p>修改时间：2019年06月28日 10:54</p>
     * <p>修改备注：</p>
     */
    public static JSONObject sendPostJsonWithBasicAuth(String url, String json, String encoding,String username,String password)  {
        // 创建httpclient对象
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            // 创建HttpClientBuilder
            HttpClientBuilder httpClientBuilder = getHttpClientBuilderBy(username,password);
            // HttpClient
            httpClient = httpClientBuilder.build();
            // 创建post方式请求对象
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/json");
            StringEntity stringEntity = new StringEntity(json, ContentType.APPLICATION_JSON);
            stringEntity.setContentEncoding(encoding);
            httpPost.setEntity(stringEntity);
            // 通过请求对象获取响应对象
            response = httpClient.execute(httpPost);
            // 获取结果实体
            JSONObject jsonObject = getResponse(response);

            log.debug("返回值={}",jsonObject);

            return jsonObject;
        }catch (IOException e){
            log.error("请求失败",e);
        }
        finally {
            close(httpClient);
            close(response);
        }
        return new JSONObject();
    }

    private static HttpClientBuilder getHttpClientBuilderBy(String username,String password){
        // 创建HttpClientBuilder
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        // 设置BasicAuth
        CredentialsProvider provider = new BasicCredentialsProvider();
        // Create the authentication scope
        AuthScope scope = new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT, AuthScope.ANY_REALM);
        // Create credential pair，在此处填写用户名和密码
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
        // Inject the credentials
        provider.setCredentials(scope, credentials);
        // Set the default credentials provider
        httpClientBuilder.setDefaultCredentialsProvider(provider);
        return httpClientBuilder;
    }

    private static JSONObject getResponse(CloseableHttpResponse response){
        JSONObject result = new JSONObject();
        try {
            result.put("httpCode",response.getStatusLine().getStatusCode());
            result.put("body",JSONObject.parseObject(EntityUtils.toString(response.getEntity(),"utf8")));
        } catch (IOException e) {
            log.error("返回值解析出错",e);
        }
        return result;
    }

    /**
     * sendGetJsonWithBasicAuth:发送get请求
     * @param url
     * @param username
     * @param password
     * @return org.apache.http.client.methods.CloseableHttpResponse
     * @exception
     * @author zane
     * @date 2019年06月28日 16:09
     */
    public static JSONObject sendGetJsonWithBasicAuth(String url, String username, String password)  {
        // 创建httpclient对象
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            // 创建HttpClientBuilder
            HttpClientBuilder httpClientBuilder = getHttpClientBuilderBy(username,password);
            // HttpClient
            httpClient = httpClientBuilder.build();
            // 创建post方式请求对象
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader("Content-type", "application/json");
            // 通过请求对象获取响应对象
            response = httpClient.execute(httpGet);

            JSONObject jsonObject = getResponse(response);

            log.debug("返回值={}",jsonObject);

            return jsonObject;

        }catch (IOException e){
            log.error("请求失败",e);
        }
        finally {
            close(httpClient);
            close(response);
        }
        return new JSONObject();
    }
}
