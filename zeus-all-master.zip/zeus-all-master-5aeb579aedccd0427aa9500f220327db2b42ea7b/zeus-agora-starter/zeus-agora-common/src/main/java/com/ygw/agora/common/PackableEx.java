package com.ygw.agora.common;

public interface PackableEx extends Packable {
    void unmarshal(ByteBuf in);
}
