package com.ygw.agora.media.autoconfig;

import com.ygw.agora.media.AgoraRecordHttpClient;
import com.ygw.agora.media.config.AgoraMediaConfig;
import com.ygw.agora.media.config.record.RecordingConfig;
import com.ygw.agora.media.config.record.StorageConfig;
import com.ygw.agora.media.token.AgoraMediaTokenBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({AgoraMediaConfig.class,RecordingConfig.class, StorageConfig.class})
public class AgoraMediaAutoConfiguration {


    @Bean
    AgoraRecordHttpClient agoraRecordHttpClient(){
        return new AgoraRecordHttpClient();
    }

    @Bean
    AgoraMediaTokenBuilder agoraMediaTokenBuilder(){
        return new AgoraMediaTokenBuilder();
    }
}
