package com.ygw.agora.media.config.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * <p>Title: RecordingConfig </p>
 * <p>Description: 录制参数配置</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zlp
 * @date 2019年10月25日 下午5:31
 * @version 1.0
 * <p>修改人:zlp </p>
 * <p>修改时间:2019年10月25日 下午5:31</p>
 * <p>修改备注:</p>
 */
@ConfigurationProperties(prefix = "agora.record")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RecordingConfig {
    /**
     * <p>（选填）Number 类型，录制的媒体流类型。</p>
     * <p>0：仅录制音频</p>
     * <p>1：仅录制视频</p>
     * <p>2：（默认）录制音频和视频</p>
     */
    private Integer streamTypes=2;

    /**
     * <p>（选填）Number 类型，解密方案。如果频道设置了加密，该参数必须设置。解密方式必须与频道设置的加密方式一致。</p>
     * <p> 0：无（默认）</p>
     * <p> 1：设置 AES128XTS 解密方案</p>
     * <p> 2：设置 AES128ECB 解密方案</p>
     * <p> 3：设置 AES256XTS 解密方案</p>
     */
    private Integer decryptionMode = 0;

    /**
     * <p>（选填）String 类型。启用解密模式后，设置的解密密码。</p>
     */
    private String secret;


    private Integer channelType=1;

    /**
     * <p>（选填）设置录制文件的音频采样率，码率，编码模式和声道数。</p>
     * <p>0：（默认）48 KHz 采样率，音乐编码，单声道，编码码率约 48 Kbps</p>
     * <p>1：48 KHz 采样率，音乐编码, 单声道，编码码率约 128 Kbps</p>
     * <p>2：48 KHz 采样率，音乐编码, 双声道，编码码率约 192 Kbps</p>
     */
    private Integer audioProfile=1;

    private Integer videoStreamType=0;

    private Integer maxIdleTime=30;

   // subscribeVideoUids：（选填）JSONArray 类型，由 UID 组成的数组，如 ["123","456"]。指定录制哪几个用户的视频流。数组长度不得超过 32。如果设置了该参数，recordingConfig 中的 streamTypes 不可为 0。
    //subscribeAudioUids：（选填）JSONArray 类型，由 UID 组成的数组，如 ["123","456"]。指定录制哪几个用户的音频流。数组长度不得超过 32。如果设置了该参数，recordingConfig 中的 streamTypes 不可为 1。
   // 一旦设置 subscribeVideoUids 和 subscribeAudioUids 中的任一参数，则只录制参数指定的音视频。例如，subscribeVideoUids 不为空，subscribeAudioUids 为空，则只录制指定用户的视频，不录制音频。如果这两个参数均为空，则录制加入频道的所有用户。

    private TranscodingConfig transcodingConfig = new TranscodingConfig();

    private List<String> subscribeVideoUids;

    private List<String> subscribeAudioUids;

    private Integer subscribeUidGroup;

    public Integer getSubscribeUidGroup() {
        return subscribeUidGroup;
    }

    public void setSubscribeUidGroup(Integer subscribeUidGroup) {
        this.subscribeUidGroup = subscribeUidGroup;
    }

    public Integer getStreamTypes() {
        return streamTypes;
    }

    public void setStreamTypes(Integer streamTypes) {
        this.streamTypes = streamTypes;
    }

    public Integer getDecryptionMode() {
        return decryptionMode;
    }

    public void setDecryptionMode(Integer decryptionMode) {
        this.decryptionMode = decryptionMode;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public Integer getAudioProfile() {
        return audioProfile;
    }

    public void setAudioProfile(Integer audioProfile) {
        this.audioProfile = audioProfile;
    }

    public Integer getVideoStreamType() {
        return videoStreamType;
    }

    public void setVideoStreamType(Integer videoStreamType) {
        this.videoStreamType = videoStreamType;
    }

    public Integer getMaxIdleTime() {
        return maxIdleTime;
    }

    public void setMaxIdleTime(Integer maxIdleTime) {
        this.maxIdleTime = maxIdleTime;
    }

    public TranscodingConfig getTranscodingConfig() {
        return transcodingConfig;
    }

    public void setTranscodingConfig(TranscodingConfig transcodingConfig) {
        this.transcodingConfig = transcodingConfig;
    }

    public List<String> getSubscribeVideoUids() {
        return subscribeVideoUids;
    }

    public void setSubscribeVideoUids(List<String> subscribeVideoUids) {
        this.subscribeVideoUids = subscribeVideoUids;
    }

    public List<String> getSubscribeAudioUids() {
        return subscribeAudioUids;
    }

    public void setSubscribeAudioUids(List<String> subscribeAudioUids) {
        this.subscribeAudioUids = subscribeAudioUids;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class TranscodingConfig {
        private Integer width = 1280;

        private Integer height = 720;

        private Integer fps = 30;

        private Integer bitrate = 3420;

        //String 类型，如果视频合流布局设为垂直布局，用该参数指定显示大视窗画面的用户 ID
        private String maxResolutionUid;

        //Number 类型，设置视频合流布局，0、1、2 为预设的合流布局，3 为自定义合流布局。该参数设为 3 时必须设置 layoutConfig 参数
        private Integer mixedVideoLayout;

        //(选填）String 类型。屏幕（画布）的背景颜色。支持 RGB 颜色表，字符串格式为 # 号后 6 个十六进制数。默认值 "#000000" 黑色
        private String backgroundColor;

        private List<LayoutConfig> layoutConfig;

        public Integer getWidth() {
            return width;
        }

        public void setWidth(Integer width) {
            this.width = width;
        }

        public Integer getHeight() {
            return height;
        }

        public void setHeight(Integer height) {
            this.height = height;
        }

        public Integer getFps() {
            return fps;
        }

        public void setFps(Integer fps) {
            this.fps = fps;
        }

        public Integer getBitrate() {
            return bitrate;
        }

        public void setBitrate(Integer bitrate) {
            this.bitrate = bitrate;
        }

        public String getMaxResolutionUid() {
            return maxResolutionUid;
        }

        public void setMaxResolutionUid(String maxResolutionUid) {
            this.maxResolutionUid = maxResolutionUid;
        }

        public Integer getMixedVideoLayout() {
            return mixedVideoLayout;
        }

        public void setMixedVideoLayout(Integer mixedVideoLayout) {
            this.mixedVideoLayout = mixedVideoLayout;
        }

        public String getBackgroundColor() {
            return backgroundColor;
        }

        public void setBackgroundColor(String backgroundColor) {
            this.backgroundColor = backgroundColor;
        }

        public List<LayoutConfig> getLayoutConfig() {
            return layoutConfig;
        }

        public void setLayoutConfig(List<LayoutConfig> layoutConfig) {
            this.layoutConfig = layoutConfig;
        }

        //（选填）JSONArray 类型。由每个用户对应的布局画面设置组成的数组，支持最多 17 个用户画面。当 mixedVideoLayout 设为 3 时，可以通过该参数自定义合流布局。一个用户画面设置包括以下参数：
        public static class LayoutConfig{
//            uid：（选填）String 类型。字符串内容为待显示在该区域的用户的 UID，32 位无符号整数。如果不指定 UID，会按照用户加入频道的顺序自动匹配 layoutConfig 中的画面设置。
//            x_axis：（必填）Float 类型。屏幕里该画面左上角的横坐标的相对值，范围是 [0.0,1.0]。从左到右布局，0.0 在最左端，1.0 在最右端。
//            y_axis：（必填）Float 类型。屏幕里该画面左上角的纵坐标的相对值，范围是 [0.0,1.0]。从上到下布局，0.0 在最上端，1.0 在最下端。
//            width：（必填）Float 类型。该画面宽度的相对值，取值范围是 [0.0,1.0]。
//            height：（必填）Float 类型。该画面高度的相对值，取值范围是 [0.0,1.0]。
//            alpha：（选填）Float 类型。图像的透明度。取值范围是 [0.0,1.0] 。默认值 1.0。0.0 表示图像为透明的，1.0 表示图像为完全不透明的。
//            render_mode：（选填）Number 类型。画面显示模式：
//                    0：（默认）裁剪模式。优先保证画面被填满。视频尺寸等比缩放，直至整个画面被视频填满。如果视频长宽与显示窗口不同，则视频流会按照画面设置的比例进行周边裁剪或图像拉伸后填满画面。
//                    1：缩放模式。优先保证视频内容全部显示。视频尺寸等比缩放，直至视频窗口的一边与画面边框对齐。如果视频尺寸与画面尺寸不一致，在保持长宽比的前提下，将视频进行缩放后填满画面，缩放后的视频四周会有一圈黑边。

            private String uid;

            private Float x_axis = 0.0f;

            private Float y_axis = 0.0f;

            private Float width = 1.0f;

            private Float height = 1.0f;

            private Float alpha  = 1.0f;

            private Integer render_mode=1;

            public LayoutConfig(){

            }
            public LayoutConfig(String uid){
                this.uid = uid;
            }
            public String getUid() {
                return uid;
            }

            public void setUid(String uid) {
                this.uid = uid;
            }

            public Float getX_axis() {
                return x_axis;
            }

            public void setX_axis(Float x_axis) {
                this.x_axis = x_axis;
            }

            public Float getY_axis() {
                return y_axis;
            }

            public void setY_axis(Float y_axis) {
                this.y_axis = y_axis;
            }

            public Float getWidth() {
                return width;
            }

            public void setWidth(Float width) {
                this.width = width;
            }

            public Float getHeight() {
                return height;
            }

            public void setHeight(Float height) {
                this.height = height;
            }

            public Float getAlpha() {
                return alpha;
            }

            public void setAlpha(Float alpha) {
                this.alpha = alpha;
            }

            public Integer getRender_mode() {
                return render_mode;
            }

            public void setRender_mode(Integer render_mode) {
                this.render_mode = render_mode;
            }
        }
    }

}
