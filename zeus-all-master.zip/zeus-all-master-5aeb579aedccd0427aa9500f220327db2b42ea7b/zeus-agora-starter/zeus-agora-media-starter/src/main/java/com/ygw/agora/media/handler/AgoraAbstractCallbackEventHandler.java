package com.ygw.agora.media.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>Title: AgoraController </p>
 * <p>Description: 声网回调</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zane
 * @date 2019年07月02日 18:41
 * @version 1.0
 * <p>修改人：zane </p>
 * <p>修改时间：2019年07月02日 18:41</p>
 * <p>修改备注：</p>
 */
public abstract class AgoraAbstractCallbackEventHandler {

    private static final Logger log = LoggerFactory.getLogger(AgoraAbstractCallbackEventHandler.class);


    private JSONObject getJsonParamFromRequest(HttpServletRequest request){
        JSONObject jsonObject= null;
        try {
            BufferedReader streamReader = new BufferedReader( new InputStreamReader(request.getInputStream(), "UTF-8"));
            StringBuilder responseStrBuilder = new StringBuilder();
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null){
                responseStrBuilder.append(inputStr);
            }

            String jsonParamStr = responseStrBuilder.toString();

            log.info("声网录制回调入参={}",jsonParamStr);

            jsonObject = JSONObject.parseObject(jsonParamStr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }



    /**
     * 生产回调签名
     * ead3798824934e0dbe1fb1ca0ab7b455  Notify Secret:  1c48ffcd8f461b09eadcd2b285111045
     */

    /**
     * recordCallback:录制回调
     * @param request
     * @param response
     * @return void
     * @exception
     * @author zane
     * @date 2019年07月02日 18:44
     */
    public void handleEvent(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONObject jsonObject = this.getJsonParamFromRequest(request);
        if(!Objects.isNull(jsonObject)){
            Optional<Integer> eventType = Optional.ofNullable(jsonObject.getInteger("eventType"));
            Optional<JSONObject> payload = Optional.ofNullable(jsonObject.getJSONObject("payload"));
            Optional<JSONObject> details = payload.map(d->d.getJSONObject("details"));
            Optional<String> sid = payload.map(d->d.getString("sid"));

            if(eventType.isPresent()){
//            1：云端录制服务发生错误
//            2：云端录制服务发生警告
//            3：云端录制服务状态发生变化
//            4：生成录制索引文件
//            30：上传服务已启动
//            31：所有录制文件已上传至指定的第三方云存储
//            32：所有录制文件已经全部上传完成，但至少有一片上传到 Agora 备份云
//            33：当前上传的进度
//            40：录制服务已启动
//            41：录制服务已退出

                String recordId = null;
                if(sid.isPresent()){
                    recordId = sid.get();
                }
                Integer status = null;
                String fileList = null;
                BigDecimal uploadProgress = null;
                Integer leaveCode = null;
                Integer state = null;
                if(details.isPresent()){
                    status = details.get().getInteger("status");
                    fileList = details.get().getString("fileList");
                    uploadProgress = details.get().getBigDecimal("progress");
                    leaveCode = details.get().getInteger("leaveCode");
                    state = details.get().getInteger("state");
                }

                switch (eventType.get()){
                    case 1:
                        log.info("声网云录制{}->云端录制服务发生错误",recordId);
                        this.cloudRecordingError(recordId,details.isPresent()?details.get():new JSONObject());
                        break;
                    case 2:
                        log.info("声网云录制{}->云端录制服务发生警告",recordId);
                        this.cloudRecordingWarning(recordId,details.isPresent()?details.get():new JSONObject());
                        break;
                    case 3:
                        log.info("声网云录制{}->云端录制服务状态发生变化",recordId);
                        this.cloudRecordingStatusUpdate(recordId,status,fileList);
                        break;
                    case 4:
                        log.info("声网云录制{}->生成录制索引文件",recordId);
                        this.cloudRecordingFileInfos(recordId,fileList);
                        break;
                    case 30:
                        log.info("声网云录制{}->上传服务已启动",recordId);
                        this.uploaderStarted(recordId,status);
                        break;
                    case 31:
                        log.info("声网云录制{}->所有录制文件已上传至指定的第三方云存储",recordId);
                        this.uploaded(recordId,status);
                        break;
                    case 32:
                        log.info("声网云录制{}->所有录制文件已经全部上传完成，但至少有一片上传到 Agora 备份云",recordId);
                        this.backuped(recordId,status);
                        break;
                    case 33:
                        log.info("声网云录制{}上传进度{}",recordId,uploadProgress);
                        this.uploadingProgress(recordId,uploadProgress);
                        break;
                    case 40:
                        log.info("声网云录制{}->录制服务已启动",recordId);
                        this.recorderStarted(recordId,status);
                        break;
                    case 41:
                        log.info("声网云录制{}已经退出",recordId);
                        this.recorderLeave(recordId,leaveCode);
                    case 42:
                        log.info("声网云录制{}录制第一片录制文件时",recordId);
                        this.recorderSliceStart(recordId,details.isPresent()?details.get():new JSONObject());
                    case 43:
                        log.info("声网云录制{}录制音频发生变化{}",recordId,state);
                        this.recorderAudioStreamStateChanged(recordId,state);
                    case 44:
                        log.info("声网云录制{}录制视频发生变化{}",recordId,state);
                        this.recorderVideoStreamStateChanged(recordId,state);
                    default:
                        break;
                }
            }
        }


        response.setStatus(200);
        response.setContentType("application/json");
        response.setCharacterEncoding("utf8");
        response.getOutputStream().write("{}".getBytes());
    }

    /**
     * 云端录制发生错误
     * @param recordId
     * @param details
     */
    public void cloudRecordingError(String recordId, JSONObject details){

    }

    /**
     * 云端录制发生警告
     * @param recordId
     * @param details
     */
    public void cloudRecordingWarning(String recordId, JSONObject details){

    }

    /**
     * 云端录制服务状态发生改变 已经被声网废弃
     * @param recordId
     * @param cloudRecordingStatus
     * 0	没有开始云端录制
     * 1	云端录制初始化完成
     * 2	录制组件开始启动
     * 3	上传组件已启动
     * 4	录制组件启动完成
     * 5	已成功上传第一个文件
     * 6	已经停止录制
     * 7	云端录制服务全部停止
     * 8	云端录制准备退出
     * 20	云端录制异常退出
     * @param fileList 录制生成的 M3U8 索引文件名
     */
    public  void cloudRecordingStatusUpdate(String recordId, Integer cloudRecordingStatus, String fileList){

    }

    /**
     * 表示已生成录制索引文件并上传
     * @param recordId
     * @param fileList 录制生成的 M3U8 索引文件名
     */
    public abstract void cloudRecordingFileInfos(String recordId, String fileList);

    /**
     * 上传开始
     * @param recordId
     * @param status 0正常 其他异常
     */
    public  void uploaderStarted(String recordId,Integer status){

    }

    /**
     * 表示所有录制文件已上传至指定的第三方云存储
     * @param recordId
     * @param status 0正常 其他异常
     */
    public void uploaded(String recordId,Number status){

    }

    /**
     * 表示所有录制文件已经全部上传完成，但至少有一片上传到 Agora 备份云， Agora 备份云会自动将这部分文件上传到指定的第三方云存储
     * @param recordId
     * @param status 0正常 其他异常
     */
    public void backuped(String recordId,Integer status){

    }

    /**
     * 上传进度
     * @param recordId
     * @param progress
     */
    public  void uploadingProgress(String recordId,BigDecimal progress){

    }

    /**
     * 录制开始
     * @param recordId
     * @param status 0正常 其他异常
     */
    public void recorderStarted(String recordId,Integer status){

    }

    /**
     * 录制退出
     * @param recordId
     * @param leaveCode
     * 0：初始化失败
     * 1：由信号触发的退出
     * 2：频道内除录制 App 外，没有其他用户
     * 4：捕获到信号错误
     * 8：wrapper 层主动退出
     */
    public abstract void recorderLeave(String recordId, Number leaveCode);

    /**
     * 录制第一片录制文件时通知（包括中断之后上传的第一片录制文件）
     * @param recordId
     * @param details
     */
    public void recorderSliceStart(String recordId,JSONObject details){

    }

    /**
     * 录制音频发生变化
     * @param recordId
     * @param state
     * 0：云端录制服务正在接收音频流
     * 1：云端录制服务未在接收音频流
     */
    public void recorderAudioStreamStateChanged(String recordId,Number state){

    }


    /**
     * 录制视频发生变化
     * @param recordId
     * @param state
     * 0：云端录制服务正在接收视频流
     * 1：云端录制服务未在接收视频流
     */
    public void recorderVideoStreamStateChanged(String recordId,Number state){

    }
}
