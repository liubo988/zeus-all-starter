package com.ygw.agora.media;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ygw.agora.common.HttpClientUtils;
import com.ygw.agora.media.config.AgoraMediaConfig;
import com.ygw.agora.media.config.record.RecordingConfig;
import com.ygw.agora.media.config.record.StorageConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.swing.text.html.Option;
import java.text.MessageFormat;
import java.util.*;

/**
 * <p>Title: AgoraRecordHttpClient </p>
 * <p>Description: 声网录制的http客户端</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zane
 * @date 2019年06月27日 14:54
 * @version 1.0
 * <p>修改人：zane </p>
 * <p>修改时间：2019年06月27日 14:54</p>
 * <p>修改备注：</p>
 */

public class AgoraRecordHttpClient {

    private static final Logger log = LoggerFactory.getLogger(AgoraRecordHttpClient.class);

    @Autowired
    private AgoraMediaConfig agoraMediaConfig;

    /**
     * 录制参数
     */
    @Autowired
    private RecordingConfig recordingConfig;

    /**
     * 存储参数
     */
    @Autowired
    private StorageConfig storageConfig;

    private static final String getResourceIdUrl = "https://api.agora.io/v1/apps/{0}/cloud_recording/acquire";

    private static final String startRecordUrl = "https://api.agora.io/v1/apps/{0}/cloud_recording/resourceid/{1}/mode/{2}/start";

    private static final String queryRecordUrl = "https://api.agora.io/v1/apps/{0}/cloud_recording/resourceid/{1}/sid/{2}/mode/{3}/query";

    private static final String stopRecordUrl = "https://api.agora.io/v1/apps/{0}/cloud_recording/resourceid/{1}/sid/{2}/mode/{3}/stop";


    public AgoraRecordHttpClient(){
    }


    public RecordingConfig getRecordingConfig() {
        return recordingConfig;
    }

    public void setRecordingConfig(RecordingConfig recordingConfig) {
        this.recordingConfig = recordingConfig;
    }

    public StorageConfig getStorageConfig() {
        return storageConfig;
    }

    public void setStorageConfig(StorageConfig storageConfig) {
        this.storageConfig = storageConfig;
    }

    /**
     * getResourceId:获取resource
     * @param channelName
     * @param uid
     * @return java.lang.String
     * @exception
     * @author zane
     * @date 2019年06月28日 11:01
     */
    public String getResourceId(String channelName,String uid){
        Map<String,Object> param = new HashMap<>();
        param.put("cname",channelName);
        param.put("uid",uid);
        param.put("clientRequest",new HashMap<>());
        JSONObject jsonObject = HttpClientUtils.sendPostJsonWithBasicAuth(MessageFormat.format(getResourceIdUrl,this.agoraMediaConfig.getAppId()), JSON.toJSONString(param),"utf8",this.agoraMediaConfig.getRestfulCustomId(),this.agoraMediaConfig.getRestfulCustomCert());


        if(getHttpCode(jsonObject)==200){
            return getBody(jsonObject).getString("resourceId");
        }
        else{
            log.error("获取声网resourceId返回失败,code={}，body={}",jsonObject);
            return null;
        }

    }

    /**
     * 使用默认配置
     * @param channelName
     * @param uid
     * @param token
     * @param resourceId
     * @return
     */
    public String startRecord(String channelName, String uid, String token, String resourceId){
        return this.startRecord(channelName,uid,token,resourceId,"mix",recordingConfig,storageConfig);
    }

    /**
     * <p>Title: AgoraRecordHttpClient </p>
     * <p>Description: 开始录制</p>
     * <p>Copyright (c) 2019 </p>
     * <p>Company: 上海阳光喔科技有限公司</p>
     * @author zane
     * @date 2019年06月28日 14:50
     * @version 1.0
     * <p>修改人：zane </p>
     * <p>修改时间：2019年06月28日 14:50</p>
     * <p>修改备注：</p>
     */
    public String startRecord(String channelName, String uid, String token, String resourceId, String mode, RecordingConfig recordingConfig, StorageConfig storageConfig ){
        Map<String,Object> clientRequest = new HashMap<>();
        clientRequest.put("recordingConfig",recordingConfig);
        clientRequest.put("storageConfig",storageConfig);
        clientRequest.put("token",token);
        Map<String,Object> param = new HashMap<>();
        param.put("cname",channelName);
        param.put("uid",uid);
        param.put("clientRequest",clientRequest);
        log.debug("开始录制--------{}",JSONObject.toJSONString(param));
        JSONObject response = HttpClientUtils.sendPostJsonWithBasicAuth(MessageFormat.format(startRecordUrl,this.agoraMediaConfig.getAppId(),resourceId,mode), JSON.toJSONString(param),"utf8",this.agoraMediaConfig.getRestfulCustomId(),this.agoraMediaConfig.getRestfulCustomCert());
        if(getHttpCode(response)==200){
            return getBody(response).getString("sid");
        }
        else{
            log.error("开始声网录制返回失败,code={}，body={}",JSONObject.toJSONString(response));
            return null;
        }
    }

    public String startRecord(String channelName, String uid, String token, String resourceId, RecordingConfig recordingConfig, StorageConfig storageConfig ) {
        return this.startRecord(channelName,uid,token,resourceId,"mix",recordingConfig,storageConfig);
    }

    private int getHttpCode(JSONObject jsonObject){
        return (int)jsonObject.getInteger("httpCode");
    }

    private JSONObject getBody(JSONObject jsonObject){
        return jsonObject.getJSONObject("body");
    }

    private List<String> getFileList(JSONObject response,String mode,String recordUrlPrefix){
        Optional<JSONObject> body = Optional.ofNullable(getBody(response));
        Optional<JSONObject> serverResponse = body.map(s->s.getJSONObject("serverResponse"));

        if("mix".equals(mode)){
            Optional<String> fileList = serverResponse.map(f->f.getString("fileList"));
            if(fileList.isPresent()){
                String fileName = recordUrlPrefix+fileList.get();
                List<String> fileListResult = new ArrayList<>();
                fileListResult.add(fileName);
                return fileListResult;
            }
            else{
                log.error("返回数据解析失败，body={}",JSONObject.toJSONString(response));
                return null;
            }
        }
        else{
            Optional<JSONArray> fileList = serverResponse.map(f->f.getJSONArray("fileList"));
            if(fileList.isPresent()){
                List<String> fileListResult = new ArrayList<>();

                JSONArray fileNameArray =fileList.get();
                for(int i=0;i<fileNameArray.size();i++){
                    JSONObject jsonObject = fileNameArray.getJSONObject(i);
                    String fileName = recordUrlPrefix+jsonObject.get("fileName");
                    fileListResult.add(fileName);
                }
                return fileListResult;
            }
            else{
                log.error("返回数据解析失败，body={}",JSONObject.toJSONString(response));
                return null;
            }
        }
    }

    /**
     * findRecord:查询录制状态
     * @param resourceId
     * @param recordId
     * @param recordUrlPrefix 在线文件前缀
     * @param mode
     * @return String
     * @exception
     * @author zane
     * @date 2019年06月28日 15:49
     */
    public List<String> findRecord(String resourceId, String recordId , String mode, String recordUrlPrefix){
        log.debug("开始查询录制--------resourceId:{},recordId:{}",resourceId,recordId);
        JSONObject response = HttpClientUtils.sendGetJsonWithBasicAuth(MessageFormat.format(queryRecordUrl,agoraMediaConfig.getAppId(),resourceId,recordId,mode),agoraMediaConfig.getRestfulCustomId(),agoraMediaConfig.getRestfulCustomCert());
        if(getHttpCode(response)==200){
            return this.getFileList(response,mode,recordUrlPrefix);
        }
        else{
            log.error("查询声网录制返回失败,code={}，body={}",getHttpCode(response),JSONObject.toJSONString(response));
            return null;
        }

    }

    public String findRecord(String resourceId,String recordId ,String recordUrlPrefix){
        List<String> fileList = this.findRecord(resourceId,recordId,"mix",recordUrlPrefix);
        if(CollectionUtils.isEmpty(fileList)){
            return null;
        }
        else{
            if(fileList.size()>0){
                return fileList.get(0);
            }
            else{
                return null;
            }
        }
    }

    /**
     *
     * @param resourceId
     * @param recordId
     * @param mode
     * @return
     */
    public int findRecordStatus(String resourceId,String recordId, String mode){
        log.debug("开始查询录制--------resourceId:{},recordId:{}",resourceId,recordId);
        JSONObject response = HttpClientUtils.sendGetJsonWithBasicAuth(MessageFormat.format(queryRecordUrl,agoraMediaConfig.getAppId(),resourceId,recordId,mode),agoraMediaConfig.getRestfulCustomId(),agoraMediaConfig.getRestfulCustomCert());
        if(getHttpCode(response)==200){
            Optional<Integer> status = this.getRecordStatus(response);
            if(status.isPresent()){
                return status.get();
            }
            else{
                log.error("查询声网录制返回数据解析失败，body={}",JSONObject.toJSONString(response));
                return -1;
            }
        }
        else{
            log.error("查询声网录制返回失败,code={}，body={}",getHttpCode(response),JSONObject.toJSONString(response));
            return -1;
        }
    }

    public int findRecordStatus(String resourceId,String recordId){
        return this.findRecordStatus(resourceId,recordId,"mix");
    }

    /**
     * 录制是否正常
     * @param resourceId
     * @param recordId
     * @return
     */
    public boolean isRecordStatusNormal(String resourceId,String recordId){
        int status = this.findRecordStatus(resourceId,recordId);
//         0：没有开始云端录制。
//         1：云端录制初始化完成。
//         2：录制组件开始启动。
//         3：上传组件启动完成。
//         4：录制组件启动完成。
//         5：已成功上传第一个文件。第一个文件上传完成后，录制在进行中均会返回此状态。
//         6：已经停止录制。
//         7：云端录制服务全部停止。
//         8：云端录制准备退出。
//         20：云端录制异常退出。

        boolean isNormal = false;
        switch (status){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                isNormal =  true;
                break;
            case 0:
            case 6:
            case 7:
            case 8:
            case 20:
                isNormal =  false;
                break;
            default:
                break;
        }

        return isNormal;
    }

    /**
     *             0：没有开始云端录制。
     *             1：云端录制初始化完成。
     *             2：录制组件开始启动。
     *             3：上传组件启动完成。
     *             4：录制组件启动完成。
     *             5：已成功上传第一个文件。第一个文件上传完成后，录制在进行中均会返回此状态。
     *             6：已经停止录制。
     *             7：云端录制服务全部停止。
     *             8：云端录制准备退出。
     *             20：云端录制异常退出。
     * @param response
     * @return
     */
    private Optional<Integer> getRecordStatus(JSONObject response){
        Optional<JSONObject> body = Optional.ofNullable(getBody(response));
        Optional<JSONObject> serverResponse = body.map(s->s.getJSONObject("serverResponse"));
        Optional<Integer> recordStatus = serverResponse.map(f->f.getInteger("status"));
        return recordStatus;
    }


   /**
    * stopRecord:停止录制
    * @param channelName
    * @param uid
    * @param resourceId
    * @param recordId
    * @param recordUrlPrefix 在线文件前缀
    * @return String
    * @exception
    * @author zane
    * @date 2019年06月28日 17:17
    */
    public List<String> stopRecord(String channelName,String uid,String resourceId,String recordId, String mode,String recordUrlPrefix){

        Map<String,Object> param = new HashMap<>();

        param.put("cname",channelName);
        param.put("uid",uid);

        Map<String,Object> clientRequest = new HashMap<>();
        param.put("clientRequest",clientRequest);
        log.debug("开始停止录制--------{}",JSONObject.toJSONString(param));

        JSONObject response = HttpClientUtils.sendPostJsonWithBasicAuth(MessageFormat.format(stopRecordUrl,this.agoraMediaConfig.getAppId(),resourceId,recordId,mode), JSON.toJSONString(param),"utf8",this.agoraMediaConfig.getRestfulCustomId(),this.agoraMediaConfig.getRestfulCustomCert());
        if(getHttpCode(response)==200){
            List<String> fileList = this.getFileList(response,mode,recordUrlPrefix);
            if(!CollectionUtils.isEmpty(fileList)){
                return fileList;
            }
            else{
                log.error("停止声网录制返回数据解析失败，body={}",JSONObject.toJSONString(response));
                return null;
            }
        }
        else{
            log.error("停止声网录制返回失败,r={}",response);
            return null;
        }
    }

    public String stopRecord(String channelName,String uid,String resourceId,String recordId,String recordUrlPrefix){
        List<String> fileList = this.stopRecord(channelName,uid, resourceId,recordId, "mix",recordUrlPrefix);
        if(CollectionUtils.isEmpty(fileList)){
            return null;
        }
        else{
            if(fileList.size()>0){
                return fileList.get(0);
            }
            else{
                return null;
            }
        }
    }
}
