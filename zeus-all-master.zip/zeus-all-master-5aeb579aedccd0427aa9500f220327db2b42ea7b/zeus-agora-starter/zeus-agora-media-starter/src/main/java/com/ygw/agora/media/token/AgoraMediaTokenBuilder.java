package com.ygw.agora.media.token;

import com.ygw.agora.common.AccessToken;
import com.ygw.agora.common.SimpleTokenBuilder;
import com.ygw.agora.media.config.AgoraMediaConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

public class AgoraMediaTokenBuilder {

    private static final Logger log = LoggerFactory.getLogger(AgoraMediaTokenBuilder.class);

    @Autowired
    private AgoraMediaConfig agoraMediaConfig;

    /**
     * 获取加入频道的token
     * @param channelName 频道id
     * @param uid 用户id
     * @param expiredTime 过期时间（秒）0表示永久
     * @param startTimestamp 过期时间开始时间戳（秒）,可以为空（默认为当前时间）
     * @return
     */
    public String getMediaToken(String channelName, String uid, Integer expiredTime, Integer startTimestamp) {
        SimpleTokenBuilder simpleTokenBuilder = new SimpleTokenBuilder(agoraMediaConfig.getAppId(),agoraMediaConfig.getAppSecret(),channelName,uid);
        if(expiredTime != null){

            if(Objects.isNull(startTimestamp)){
                startTimestamp = (int)(System.currentTimeMillis()/1000);
            }

            //转换为时间戳
            expiredTime = startTimestamp+expiredTime;

            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kJoinChannel,expiredTime);
            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kPublishAudioStream,expiredTime);
            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kPublishVideoStream,expiredTime);
            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kPublishDataStream,expiredTime);

            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kInvitePublishAudioStream,expiredTime);
            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kInvitePublishVideoStream,expiredTime);
            simpleTokenBuilder.setPrivilege(AccessToken.Privileges.kInvitePublishDataStream,expiredTime);
        }
        String token = null;
        try {
            token = simpleTokenBuilder.buildToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return token;
    }

}
