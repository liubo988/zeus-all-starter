package com.ygw.agora.media.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "agora.media")
public class AgoraMediaConfig {
    /**
     * appId
     */
    private String appId = "47d6c29933c841948650e95f78bfc010";

    /**
     * appSecret
     */
    private String appSecret = "aac5df9418714efcb2f77003279c9fdb";

    /**
     * restful的客户id
     */
    private String restfulCustomId = "83d949b94dbd4d2a9235a21b2884835a";

    /**
     * restful的客户密码
     */
    private String restfulCustomCert = "00265472d6bb4c7999a65c3ccdb7ef3b";

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getRestfulCustomId() {
        return restfulCustomId;
    }

    public void setRestfulCustomId(String restfulCustomId) {
        this.restfulCustomId = restfulCustomId;
    }

    public String getRestfulCustomCert() {
        return restfulCustomCert;
    }

    public void setRestfulCustomCert(String restfulCustomCert) {
        this.restfulCustomCert = restfulCustomCert;
    }
}
