package com.ygw.agora.media.config.record;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * <p>Title: StorageConfig </p>
 * <p>Description: 存储配置</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zlp
 * @date 2019年10月25日 下午5:32
 * @version 1.0
 * <p>修改人:zlp </p>
 * <p>修改时间:2019年10月25日 下午5:32</p>
 * <p>修改备注:</p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@ConfigurationProperties(prefix = "agora.record.storage")
public class StorageConfig {


    //
//        vendor：Number 类型，第三方云存储供应商。
//
//                0：七牛云
//1：Amazon S3
//2：阿里云
//        region：Number 类型，第三方云存储指定的地区信息。
//        当 vendor = 0，即第三方云存储为七牛云时：
//
//                0：Huadong
//1：Huabei
//2：Huanan
//3：Beimei
//        当 vendor = 1，即第三方云存储为 Amazon S3 时：
//
//                0：US_EAST_1
//1：US_EAST_2
//2：US_WEST_1
//3：US_WEST_2
//4：EU_WEST_1
//5：EU_WEST_2
//6：EU_WEST_3
//7：EU_CENTRAL_1
//8：AP_SOUTHEAST_1
//9：AP_SOUTHEAST_2
//10：AP_NORTHEAST_1
//11：AP_NORTHEAST_2
//12：SA_EAST_1
//13：CA_CENTRAL_1
//14：AP_SOUTH_1
//15：CN_NORTH_1
//16：CN_NORTHWEST_1
//17：US_GOV_WEST_1
//        当 vendor = 2，即第三方云存储为阿里云时：
//
//                0：CN_Hangzhou
//1：CN_Shanghai
//2：CN_Qingdao
//3：CN_Beijin
//4：CN_Zhangjiakou
//5：CN_Huhehaote
//6：CN_Shenzhen
//7：CN_Hongkong
//8：US_West_1
//9：US_East_1
//10：AP_Southeast_1
//11：AP_Southeast_2
//12：AP_Southeast_3
//13：AP_Southeast_5
//14：AP_Northeast_1
//15：AP_South_1
//16：EU_Central_1
//17：EU_West_1
//18：EU_East_1
//        bucket：String 类型，第三方云存储的 bucket。
//
//        accessKey：String 类型，第三方云存储的 access key。
//
//        secretKey：String 类型，第三方云存储的 secret key。

    private Integer vendor = 2;

    private Integer region = 1;

    private String bucket = "teaching-live";

    private String accessKey = "LTAIlYB9e7u2WG9R";

    private String secretKey = "bSQ0lZmpPRHwYPFTjzEzbBQHVljTtI";

    private List<String> fileNamePrefix;

    public Integer getVendor() {
        return vendor;
    }

    public void setVendor(Integer vendor) {
        this.vendor = vendor;
    }

    public Integer getRegion() {
        return region;
    }

    public void setRegion(Integer region) {
        this.region = region;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public List<String> getFileNamePrefix() {
        return fileNamePrefix;
    }
    public void setFileNamePrefix(List<String> fileNamePrefix) {
        this.fileNamePrefix = fileNamePrefix;
    }
}
