package com.ygw.agora.media;

import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Optional;

@SpringBootApplication
public class AgoraMediaApplicationTests implements CommandLineRunner {

    @Autowired
    private AgoraRecordHttpClient agoraRecordHttpClient;

    public static void main(String[] args) {
        SpringApplication.run(AgoraMediaApplicationTests.class, args);
    }

    @Override
    public void run(String... strings) throws Exception {

//        AgoraRtmClient a = agoraRtmClientBuilder.createAgoraRtmClient("eterere",false,0);
//        a.joinChannel("1111");
//        a.sendChannelMessage("1111","fuck");

//        agoraRecordHttpClient.stopRecord("ttt","rerer","tt","ff","");

        while (true){
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("body",new JSONObject());

            this.getFileList(jsonObject);

        }
    }

    private JSONObject getBody(JSONObject jsonObject){
        return jsonObject.getJSONObject("body");
    }

    private Optional<String> getFileList(JSONObject response){
        Optional<JSONObject> body = Optional.ofNullable(getBody(response));
        Optional<JSONObject> serverResponse = body.map(s->body.get().getJSONObject("serverResponse"));
        Optional<String> fileList = serverResponse.map(f->serverResponse.get().getString("fileList"));
        return fileList;
    }
}
