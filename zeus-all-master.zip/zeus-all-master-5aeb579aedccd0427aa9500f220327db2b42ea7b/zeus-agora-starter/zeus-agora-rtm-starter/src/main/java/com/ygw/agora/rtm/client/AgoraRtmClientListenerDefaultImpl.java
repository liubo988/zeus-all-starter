package com.ygw.agora.rtm.client;

import io.agora.rtm.RtmClientListener;
import io.agora.rtm.RtmMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AgoraRtmClientListenerDefaultImpl implements RtmClientListener {

    private static final Logger log = LoggerFactory.getLogger(AgoraRtmClientListenerDefaultImpl.class);

    private AgoraRtmClientEventHandler agoraRtmClientEventHandler;

    private AgoraRtmClient agoraRtmClient;

    public AgoraRtmClientListenerDefaultImpl(){

    }

    public AgoraRtmClientListenerDefaultImpl(AgoraRtmClient agoraRtmClient,AgoraRtmClientEventHandler agoraRtmClientEventHandler){
        this.agoraRtmClient = agoraRtmClient;
        this.agoraRtmClientEventHandler = agoraRtmClientEventHandler;
    }


    @Override
    public void onConnectionStateChanged(int state, int reason) {

        switch (state){
            case 1:
                log.info("监听信息：{}初始化",agoraRtmClient.getUserId());
                break;
            case 2:
                log.info("监听信息：{}正在登录",agoraRtmClient.getUserId());
                break;
            case 3:
                log.info("监听信息：{}登录成功",agoraRtmClient.getUserId());
                if(agoraRtmClientEventHandler != null){
                    agoraRtmClientEventHandler.loginSuccess(agoraRtmClient.getUserId());
                }
                break;
            case 4:
                log.info("监听信息：{}正在重连",agoraRtmClient.getUserId());
                if(agoraRtmClientEventHandler != null){
                    agoraRtmClientEventHandler.reconnecting(agoraRtmClient.getUserId());
                }
                break;
            case 5:
                log.info("监听信息：{}停止登录",agoraRtmClient.getUserId());
                if(agoraRtmClientEventHandler != null){
                    agoraRtmClientEventHandler.aborted(agoraRtmClient.getUserId());
                }
                agoraRtmClient.setLogin(false);
                break;
            default:
                log.info("监听信息：{}未知的连接状态",agoraRtmClient.getUserId());
                break;

        }

    }

    @Override
    public void onMessageReceived(RtmMessage rtmMessage, String peerId) {
        String msg = rtmMessage.getText();
        log.info("监听信息：{}接收到来自:{}的消息:{}",  agoraRtmClient.getUserId(),msg, peerId);
        agoraRtmClientEventHandler.receiveMessage(peerId,rtmMessage.getText());
    }

    @Override
    public void onTokenExpired() {
        log.debug("tokenExpired ");
    }
}
