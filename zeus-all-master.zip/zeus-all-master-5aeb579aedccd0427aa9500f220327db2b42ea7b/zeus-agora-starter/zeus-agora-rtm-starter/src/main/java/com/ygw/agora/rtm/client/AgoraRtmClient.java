package com.ygw.agora.rtm.client;


import com.ygw.agora.common.AccessToken;
import com.ygw.agora.rtm.config.AgoraRtmConfig;
import com.ygw.agora.rtm.token.RtmTokenBuilder0;
import com.ygw.agora.rtm.token.TokenSetting;
import io.agora.rtm.*;
import org.apache.http.client.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class AgoraRtmClient {


    private static final Logger log = LoggerFactory.getLogger(AgoraRtmClient.class);

    private RtmClient mRtmClient;

    private Map<String, RtmChannel> mRtmChannelMap = new Hashtable<>();

    private boolean login = false;

    private String userId = null;

    private String token = null;

    public boolean isLogin() {
        return login;
    }

    public void setLogin(boolean login) {
        this.login = login;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean isLinux() {
        String os = System.getProperty("os.name").toLowerCase();
        log.info("系统名称{}",os);
        return os.indexOf("linux")>-1;
    }

    /**
     * int 	CONNECTION_STATE_DISCONNECTED = 1  初始状态
     * int 	CONNECTION_STATE_CONNECTING = 2 正在登录
     * int 	CONNECTION_STATE_CONNECTED = 3 登录成功
     * int 	CONNECTION_STATE_RECONNECTING = 4  正在尝试自动重连
     * int 	CONNECTION_STATE_ABORTED = 5 停止登录 可能原因：另一实例已经以同一用户 ID 登录 Agora RTM 系统
     * @param agoraRtmConfig
     * @param handler
     * @param userId
     * @param tokenSetting
     */

    public AgoraRtmClient(AgoraRtmConfig agoraRtmConfig, AgoraRtmClientEventHandler handler, String userId, TokenSetting tokenSetting){
        try {

            if(!agoraRtmConfig.getEnableRtm()){
                log.warn("声网即时消息服务未启动");
                return;
            }
            String appId = agoraRtmConfig.getAppId();
            String appSecret = agoraRtmConfig.getAppSecret();

            this.userId = userId;

            if(tokenSetting.isUseToken()){
                RtmTokenBuilder0 tokenBuilder = new RtmTokenBuilder0(appId,appSecret, userId);
                tokenBuilder.setPrivilege(AccessToken.Privileges.kRtmLogin,tokenSetting.getExpireTimestamp());
                this.token = tokenBuilder.buildToken();
            }


            if(!this.isLinux()){
                log.error("非linux不支持声网即时消息");
                return;
            }

            mRtmClient = RtmClient.createInstance(appId,new AgoraRtmClientListenerDefaultImpl(this,handler));
            String logPath ="/home/logs/agorartm/"+ DateUtils.formatDate(new Date(),"yyyyMMdd") +"/"+ userId+".log";
            log.info("rtm日志路径{}",logPath);
            mRtmClient.setLogFile(logPath);


            log.info("appId:{},appSecret:{},userId:{},token:{}",appId,appSecret,this.userId,this.token);

        } catch (Exception e) {
            log.error("声网RTM客户端初始化失败",e);
        }
    }

    /**
     * 设置日志
     * @param logPath
     * @param size
     */
    public void setRtmLog(String logPath,int size){
        mRtmClient.setLogFileSize(size);
        mRtmClient.setLogFile(logPath);
    }

    public RtmChannel getValidChannel(String channelName){
        return mRtmChannelMap.get(channelName);
    }

    /**
     * login:登录
//     * @param userId
     * @return void
     * @exception
     * @author zane
     * @date 2019年07月08日 16:15
     */
    public void login(){
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return;
        }

        mRtmClient.login(this.token, this.userId, new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void responseInfo) {
                log.info("登录成功.账户{}",userId);
                login = true;
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                log.info("{}登录失败{}",userId,errorInfo.getErrorCode()+":"+errorInfo.getErrorDescription());
            }
        });
    }

    private void loginOut0(final boolean[] alwaysRetry, int waitTime) {
        final boolean[] logoutSuccess = {false};

        mRtmClient.logout(new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void responseInfo) {
                log.info("{}登出成功",userId);
                login = false;

                logoutSuccess[0] = false;
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                log.debug("{}登出失败{}",userId,errorInfo.getErrorCode()+":"+errorInfo.getErrorDescription());
            }
        });

        /**
         * 退出回调的最大等待时间
         */
        int i = waitTime;
        if(waitTime<100){
            i=100;
        }
        while(!logoutSuccess[0] && i>0){
            try {
                Thread.sleep(100);
                i--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * loginOut:登出
     * @return void
     * @exception
     * @author zane
     * @date 2019年07月08日 16:16
     */
    public void loginOut(){
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return;
        }

        if(mRtmChannelMap != null && mRtmChannelMap.size()>0){
            for(String channel:mRtmChannelMap.keySet()){
                this.leaveChannel(channel,true);
            }
        }
        log.info("登出客户端{}",userId);

//        final boolean[] alwaysRetry = {false};
//        this.loginOut0(alwaysRetry,1000);
//
//
//        //重试
//        int retryCount = 3;
//        while (alwaysRetry[0] && retryCount> 0){
//            try {
//                Thread.sleep(100);
//                retryCount--;
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            this.loginOut0(alwaysRetry,1000);
//        }

        mRtmClient.release();

        this.login = false;
    }

    /**
     * sendPeerMessage:发送消息
     * @param dst
     * @param message
     * @return void
     * @exception
     * @author zane
     * @date 2019年07月09日 9:43
     */
    public void sendPeerMessage(String dst, String message) {
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return;
        }

        RtmMessage msg = mRtmClient.createMessage();
        msg.setText(message);

        mRtmClient.sendMessageToPeer(dst, msg, new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                log.info("发送给{}消息{}成功", dst,message);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                final int errorCode = errorInfo.getErrorCode();
                log.info("发送点对点消息{}给{}失败{}", dst,message,errorCode);
            }
        });
    }

    /**
     *
     * @param rtmChannel
     * @param channel
     * @param alwaysRetry
     * @param waitTime 为了保证rtmChannel创建成功的最大等待时间
     * */
    private void join0(RtmChannel rtmChannel,String channel,final boolean[] alwaysRetry, int waitTime){
        final boolean[] joinSuccess = {false};

        rtmChannel.join(new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void responseInfo) {
                log.info("{}加入频道{}成功",getUserId(),channel);
                joinSuccess[0] = true;
                mRtmChannelMap.put(channel,rtmChannel);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                log.info("{}加入频道{}失败，错误信息：{}",getUserId(),channel,errorInfo.getErrorDescription());
                alwaysRetry[0] = true;

                /**
                 * int 	JOIN_CHANNEL_ERR_OK = 0
                 * int 	JOIN_CHANNEL_ERR_FAILURE = 1
                 * int 	JOIN_CHANNEL_ERR_REJECTED = 2
                 * int 	JOIN_CHANNEL_ERR_INVALID_ARGUMENT = 3
                 * int 	JOIN_CHANNEL_TIMEOUT = 4
                 * int 	JOIN_CHANNEL_ERR_EXCEED_LIMIT = 5
                 * int 	JOIN_CHANNEL_ERR_ALREADY_JOINED = 6
                 * int 	JOIN_CHANNEL_ERR_TOO_OFTEN = 7
                 * JOIN_CHANNEL_ERR_JOIN_SAME_CHANNEL_TOO_OFTEN = 8
                 * int 	JOIN_CHANNEL_ERR_NOT_INITIALIZED = 101
                 * int 	JOIN_CHANNEL_ERR_USER_NOT_LOGGED_IN = 102
                 */
                if(6==errorInfo.getErrorCode()){
                    joinSuccess[0] = true;
                }
            }
        });

        /**
         * 回调的最大等待时间
         */
        int i = waitTime;
        if(waitTime<100){
            i=100;
        }
        while(!joinSuccess[0] && i>0){
            try {
                Thread.sleep(100);
                i--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * joinChannel:加入频道
     * @param channel
     * @return io.agora.rtm.RtmChannel
     * @exception
     * @author zane
     * @date 2019年07月09日 9:59
     */
    public RtmChannel joinChannel(String channel){
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return null;
        }

        RtmChannel rtmChannel = this.getValidChannel(channel);
        if(rtmChannel == null){
            rtmChannel = mRtmClient.createChannel(channel,new ChannelListener(channel));

            final boolean[] alwaysRetry = {false};
            this.join0(rtmChannel,channel,alwaysRetry,1000);


            //重试
            int retryCount = 3;
            while (alwaysRetry[0] && retryCount> 0){
                try {
                    Thread.sleep(100);
                    retryCount--;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                this.join0(rtmChannel,channel,alwaysRetry,1000);
            }
        }

        return rtmChannel;
    }

    private void leaveChannel0(RtmChannel rtmChannel,String channel,final boolean[] alwaysRetry, int waitTime){
        final boolean[] leaveSuccess = {false};

        rtmChannel.leave(new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void responseInfo) {
                log.info("{}离开频道{}成功",getUserId(),channel);
                leaveSuccess[0] = true;
                mRtmChannelMap.remove(channel);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                alwaysRetry[0] = true;

                /**
                 * int 	LEAVE_CHANNEL_ERR_OK = 0
                 * int 	LEAVE_CHANNEL_ERR_FAILURE = 1
                 * int 	LEAVE_CHANNEL_ERR_REJECTED = 2
                 * int 	LEAVE_CHANNEL_ERR_NOT_IN_CHANNEL = 3
                 * int 	LEAVE_CHANNEL_ERR_NOT_INITIALIZED = 101
                 * int 	LEAVE_CHANNEL_ERR_USER_NOT_LOGGED_IN = 102
                 */

                if(3==errorInfo.getErrorCode() || 102==errorInfo.getErrorCode()){
                    leaveSuccess[0] = true;
                }

                log.info("{}离开频道{}失败，错误信息：{}",getUserId(),channel,errorInfo.getErrorDescription());
            }
        });

        /**
         * 离开频道回调的最大等待时间
         */
        int i = waitTime;
        if(waitTime<100){
            i=100;
        }
        while(!leaveSuccess[0] && i>0){
            try {
                Thread.sleep(100);
                i--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * leaveChannel0:一句话描述方法功能
     * @param channel
     * @param force 是否强制退出频道 ，false 表示超过超过10个频道才退出
     * @return void
     * @exception
     * @author zane
     * @date 2019年10月08日 14:08
     */
    public void leaveChannel(String channel,boolean force){
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return;
        }

        log.info("{}已经加入{}个频道",this.userId,this.mRtmChannelMap.size());

        if(mRtmChannelMap.size()<10 && !force){
            log.info("未超过10个活动频道，不退出频道");
            return;
        }
        else{
            log.info("准备退出频道{}",channel);
        }

        RtmChannel rtmChannel = this.getValidChannel(channel);
        if(rtmChannel != null){

//            final boolean[] alwaysRetry = {false};
//            this.leaveChannel0(rtmChannel,channel,alwaysRetry,1000);
//
//
//            //重试
//            int retryCount = 3;
//            while (alwaysRetry[0] && retryCount> 0){
//                try {
//                    Thread.sleep(100);
//                    retryCount--;
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                this.leaveChannel0(rtmChannel,channel,alwaysRetry,1000);
//            }

            //释放
            rtmChannel.release();

            this.mRtmChannelMap.remove(channel);

        }

        return;
    }

    /**
     * sendChannelMessage:发送频道消息
     * @param channel
     * @param msg
     * @return void
     * @exception
     * @author zane
     * @date 2019年07月09日 10:00
     */
    public void sendChannelMessage(String channel,String msg) {
       this.sendChannelMessage(channel,msg,true);
    }

    private void sendChannelMessage0(RtmChannel rtmChannel,String channel,RtmMessage message,String msg, final boolean[] alwaysRetry, int waitTime){

        final boolean[] sended = {false};

        rtmChannel.sendMessage(message, new ResultCallback<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                log.info("{}发送频道{}消息{}成功",getUserId(),channel,msg);

                sended[0] = true;
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                log.info("{}发送频道{}消息{}失败,{}",getUserId(),channel,msg,errorInfo.getErrorDescription());
//                int 	CHANNEL_MESSAGE_ERR_OK = 0
//                int 	CHANNEL_MESSAGE_ERR_FAILURE = 1
//                int 	CHANNEL_MESSAGE_ERR_TIMEOUT = 2
//                int 	CHANNEL_MESSAGE_ERR_TOO_OFTEN = 3
//                int 	CHANNEL_MESSAGE_ERR_INVALID_MESSAGE = 4
//                int 	CHANNEL_MESSAGE_ERR_NOT_INITIALIZED = 101
//                int 	CHANNEL_MESSAGE_ERR_USER_NOT_LOGGED_IN = 102
                alwaysRetry[0] = true;
            }
        });

        int i = waitTime;
        if(i<100){
            i=100;
        }
        while(!sended[0] && i>0){
            try {
                Thread.sleep(10);
                i--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 释放资源
     */
    private void release(){
        try {
            log.info("{}登出释放资源",this.userId);
            mRtmClient.release();
        }catch (Exception e){
            log.error("释放失败",e);
        }
    }


    /**
     * sendChannelMessage:一句话描述方法功能
     * @param channel
     * @param msg
     * @param forceLeaveChannel  是否强制退出频道
     * @return void
     * @exception
     * @author zane
     * @date 2019年10月08日 14:07
     */
    public void sendChannelMessage(String channel,String msg,boolean forceLeaveChannel) {

        if(mRtmClient == null){
            log.error("发送频道消息失败，客户端未初始化，{}，{}",channel,msg);
            return;
        }


        RtmChannel rtmChannel = this.joinChannel(channel);
        if(rtmChannel == null){
            log.error("发送频道消息失败，频道未初始化成功，{}，{}",channel,msg);
            return;
        }

        RtmMessage message = mRtmClient.createMessage();
        message.setText(msg);

        final boolean[] alwaysRetry = {false};
        this.sendChannelMessage0(rtmChannel,channel,message,msg,alwaysRetry,1000);

        //重试
        int retryCount = 3;
        while (alwaysRetry[0] && retryCount> 0){
            try {
                Thread.sleep(5);
                retryCount--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            this.sendChannelMessage0(rtmChannel,channel,message,msg,alwaysRetry,1000);
        }

        this.leaveChannel(channel,forceLeaveChannel);
    }

    public void getChannelMemberList(String channel) {
        if(mRtmClient == null){
            log.error("声网即时消息客户端初始化失败");
            return;
        }

        RtmChannel rtmChannel = this.joinChannel(channel);


        rtmChannel.getMembers(new ResultCallback<List<RtmChannelMember>>() {
            @Override
            public void onSuccess(final List<RtmChannelMember> responseInfo) {
                for (int i = 0; i < responseInfo.size(); i++) {
                    log.info(("memberlist[" + i + "]" + ": "+responseInfo.get(i).getUserId()));
                }
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                log.info("查询成员失败{},{},{}",channel,errorInfo.getErrorDescription());
            }
        });
    }


    class ChannelListener implements RtmChannelListener {
        private String channel_;

        public ChannelListener(String channel) {
            channel_ = channel;
        }
        @Override
        public void onMessageReceived(
                final RtmMessage message, final RtmChannelMember fromMember) {
            String account = fromMember.getUserId();
            String msg = message.getText();
            log.info("收到频道：{}消息:{}成员：{} message:{} " , channel_, account , msg);
        }

        @Override
        public void onMemberJoined(RtmChannelMember member) {
            String account = member.getUserId();
            log.info("加入频道：{} 成员：{} message:{} " , channel_, account );

        }

        @Override
        public void onMemberLeft(RtmChannelMember member) {
            String account = member.getUserId();
            log.info("离开频道：{} 成员：{} message:{} " , channel_, account );

        }
    }
    @PostConstruct
    public void destory(){
        loginOut();
    }

}