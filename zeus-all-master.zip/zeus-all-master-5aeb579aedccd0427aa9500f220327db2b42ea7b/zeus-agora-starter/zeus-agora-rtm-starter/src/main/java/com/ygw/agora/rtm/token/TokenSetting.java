package com.ygw.agora.rtm.token;

public class TokenSetting {

    /**
     * 是否使用token
     */
    private boolean useToken;

    /**
     * 过期的时间戳(秒),0表示永久有效
     */
    private Integer expireTimestamp=0;

    public TokenSetting(){

    }


    public TokenSetting(boolean useToken,Integer expireTimestamp){
        this.useToken = useToken;
        this.expireTimestamp = expireTimestamp;
    }

    public boolean isUseToken() {
        return useToken;
    }

    public void setUseToken(boolean useToken) {
        this.useToken = useToken;
    }

    public Integer getExpireTimestamp() {
        return expireTimestamp;
    }

    public void setExpireTimestamp(Integer expireTimestamp) {
        this.expireTimestamp = expireTimestamp;
    }
}
