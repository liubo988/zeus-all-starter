package com.ygw.agora.rtm.autoconfig;

import com.ygw.agora.rtm.client.AgoraRtmClientManager;
import com.ygw.agora.rtm.client.AgoraRtmClientEventHandler;
import com.ygw.agora.rtm.config.AgoraRtmConfig;
import com.ygw.agora.rtm.token.AgoraRtmTokenBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration
@EnableConfigurationProperties(AgoraRtmConfig.class)
public class AgoraRtmAutoConfiguration {

    @ConditionalOnMissingBean(AgoraRtmTokenBuilder.class)
    @Bean
    AgoraRtmTokenBuilder agoraRtmTokenBuilder(){
        return new AgoraRtmTokenBuilder();
    }

    @ConditionalOnMissingBean(AgoraRtmClientEventHandler.class)
    @Bean
    AgoraRtmClientEventHandler agoraRtmClientEventHandler(){
        return new AgoraRtmClientEventHandler() {
            @Override
            public void loginSuccess(String userId) {

            }

            @Override
            public void reconnecting(String userId) {

            }

            @Override
            public void aborted(String userId) {

            }

            @Override
            public void receiveMessage(String receiverId, String message) {

            }
        };
    }

    @DependsOn("agoraRtmClientEventHandler")
    @ConditionalOnMissingBean(AgoraRtmClientManager.class)
    @Bean
    AgoraRtmClientManager agoraRtmClientBuilder(){
        return new AgoraRtmClientManager();
    }


}
