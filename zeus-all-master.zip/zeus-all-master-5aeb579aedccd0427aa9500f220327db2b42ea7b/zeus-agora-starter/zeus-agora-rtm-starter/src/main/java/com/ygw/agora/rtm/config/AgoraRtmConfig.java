package com.ygw.agora.rtm.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>Title: AgoraConfig </p>
 * <p>Description: 声网配置</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zane
 * @date 2019年07月01日 14:48
 * @version 1.0
 * <p>修改人：zane </p>
 * <p>修改时间：2019年07月01日 14:48</p>
 * <p>修改备注：</p>
 */
@ConfigurationProperties(prefix = "agora.rtm")
public class AgoraRtmConfig {
    /**
     * appId
     */
    private String appId = "47d6c29933c841948650e95f78bfc010";

    /**
     * appSecret
     */
    private String appSecret = "aac5df9418714efcb2f77003279c9fdb";

    /**
     * 是否启用rtm
     */
    private Boolean enableRtm = true;


    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public Boolean getEnableRtm() {
        return enableRtm;
    }

    public void setEnableRtm(Boolean enableRtm) {
        this.enableRtm = enableRtm;
    }
}
