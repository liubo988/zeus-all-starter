package com.ygw.agora.rtm.client;

import com.ygw.agora.rtm.config.AgoraRtmConfig;
import com.ygw.agora.rtm.token.TokenSetting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

/**
 * <p>Title: AgoraRtmClientFactory </p>
 * <p>Description: 实时消息客户端容器</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zane
 * @date 2019年10月08日 14:29
 * @version 1.0
 * <p>修改人：zane </p>
 * <p>修改时间：2019年10月08日 14:29</p>
 * <p>修改备注：</p>
 */
public class AgoraRtmClientManager {

    private static final Logger log = LoggerFactory.getLogger(AgoraRtmClientManager.class);

    @Autowired
    private AgoraRtmConfig agoraRtmConfig;

    @Autowired
    private AgoraRtmClientEventHandler agoraRtmClientEventHandler;


    private Map<String, AgoraRtmClient> rtmClientHashtable = new Hashtable<>();

    private String userIdSuffix = null;

    private String userIdPrefix = null;

    public AgoraRtmClientManager(){
        log.info("创建rtmBuilder");
    }

    public AgoraRtmClientManager(String userIdPrefix, String userIdSuffix){
        this.userIdPrefix = userIdPrefix;
        this.userIdSuffix = userIdSuffix;

        log.info("创建rtmBuilder,前缀{}，后缀{}",userIdPrefix,userIdSuffix);
    }

    private String addUserIdPrefixAndSuffix(String userId){
        String realUserId = userId;
        if(!StringUtils.isEmpty(userIdPrefix)){
            realUserId = userIdPrefix+realUserId;
        }

        if(!StringUtils.isEmpty(userIdSuffix)){
            realUserId = realUserId+userIdSuffix;
        }
        return realUserId;
    }

    public AgoraRtmConfig getAgoraRtmConfig() {
        return agoraRtmConfig;
    }

    public void setAgoraRtmConfig(AgoraRtmConfig agoraRtmConfig) {
        this.agoraRtmConfig = agoraRtmConfig;
    }



    /**
     * 创建永久有效的客户端
     * @param userId
     * @return
     */
    public synchronized AgoraRtmClient getInstance(String userId){
        return this.getInstance(userId,true,0);
    }

    /**
     * 创建带登录有效期的客户端
     * @param userId
     * @param expireTimestampSeconds 过期时间戳
     * @return
     */
    public synchronized AgoraRtmClient getInstance(String userId, Integer expireTimestampSeconds){
        return this.getInstance(userId,true,expireTimestampSeconds);
    }

    /**
     * 创建不需要使用token的客户端
     * @param userId
     * @return
     */
    public synchronized AgoraRtmClient getInstanceWithNoToken(String userId){
        return this.getInstance(userId,false,0);
    }

    /**
     *
     * @param userId
     * @param useToken
     * @param expireTimestampSeconds 0 表示token不过期
     * @return
     */
    public synchronized AgoraRtmClient getInstance(String userId, boolean useToken, Integer expireTimestampSeconds){
        String realUserId = this.addUserIdPrefixAndSuffix(userId);

        AgoraRtmClient agoraRtmClient = rtmClientHashtable.get(realUserId);
        if(agoraRtmClient == null){
            //创建
            agoraRtmClient = new AgoraRtmClient(agoraRtmConfig,agoraRtmClientEventHandler,realUserId,new TokenSetting(useToken,expireTimestampSeconds));
            log.info("创建客户端{}",realUserId);
        }

        if(!agoraRtmClient.isLogin()){
            //登录
            agoraRtmClient.login();
            int i=3;
            while (i>0){
                i--;
                if(!agoraRtmClient.isLogin()){
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        log.error("异常");
                    }
                }
            }

            rtmClientHashtable.put(realUserId,agoraRtmClient);
        }

        return agoraRtmClient;
    }

    /**
     * 清空客户端
     */
    public synchronized void removeAll(){
        for(Iterator<Map.Entry<String,AgoraRtmClient>> it=rtmClientHashtable.entrySet().iterator();it.hasNext();){
            Map.Entry<String,AgoraRtmClient> entry = it.next();
            AgoraRtmClient agoraRtmClient = entry.getValue();
            if(agoraRtmClient== null){
                //删除记录
                it.remove();
                continue;
            }
            //退出客户端
            agoraRtmClient.loginOut();
            log.info("删除客户端{}",agoraRtmClient.getUserId());

            //删除记录
            it.remove();
        }
    }

    /**
     * 发送频道消息
     * @param clientUserId 客户端userId（发送端的客户id）
     * @param channelName 频道id
     * @param jsonMessage 消息内容
     * @return
     */
    public boolean sendMessage(String clientUserId, String channelName, String jsonMessage){
        return this.sendMessage(clientUserId,channelName,jsonMessage,false);
    }

    /**
     * 发送频道消息
     * @param clientUserId 客户端userId（发送端的客户id）
     * @param channelName 频道id
     * @param jsonMessage 消息内容
     * @param forceLeaveChannel 是否在发送消息之后退出频道
     * @return
     */
    public boolean sendMessage(String clientUserId, String channelName, String jsonMessage, boolean forceLeaveChannel) {
        try {
            this.getInstance(clientUserId).sendChannelMessage(channelName,jsonMessage,forceLeaveChannel);
        }catch (Exception e){
            log.error("频道消息发送操作失败-"+"客户端:"+this.addUserIdPrefixAndSuffix(clientUserId)+"频道："+channelName,e);
            return false;
        }
        return true;
    }

    /**
     * @param clientUserId 客户端userId（发送端的客户id）
     * @param account 接收方的userId
     * @param jsonMessage 消息内容
     * @return
     */
    public boolean sendP2PMessage(String clientUserId, String account, String jsonMessage) {
        try {
            this.getInstance(clientUserId).sendPeerMessage(account,jsonMessage);
        }catch (Exception e){
            log.error("点对点消息发送操作失败",e);
            return false;
        }
        return true;
    }
}
