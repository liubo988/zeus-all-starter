package com.ygw.agora.rtm.token;


import com.ygw.agora.common.AccessToken;
import com.ygw.agora.rtm.config.AgoraRtmConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class AgoraRtmTokenBuilder {
    private static final Logger log = LoggerFactory.getLogger(AgoraRtmTokenBuilder.class);

    @Autowired
    private AgoraRtmConfig agoraRtmConfig;

    /**
     * 获取登录使用的token
     * @param uid
     * @param expiredTime 过期时间（秒）0表示永久
     * @param startTimestamp 过期时间开始时间戳（秒）,可以为空（默认为当前时间）
     * @return
     */
    public String getRtmToken(String uid, Integer expiredTime, Integer startTimestamp) {
        String result = null;
        try {
            RtmTokenBuilder0 tokenBuilder = new RtmTokenBuilder0(agoraRtmConfig.getAppId(),agoraRtmConfig.getAppSecret(), uid);
            if(expiredTime != null){

                if(startTimestamp == null){
                    startTimestamp = (int)(System.currentTimeMillis()/1000);
                }
                else{
                    if(expiredTime==0){
                        //do nothing
                    }
                    else{
                        //转换为时间戳
                        expiredTime = startTimestamp+expiredTime;
                    }
                }


                tokenBuilder.setPrivilege(AccessToken.Privileges.kRtmLogin,expiredTime);

            }
            result = tokenBuilder.buildToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
