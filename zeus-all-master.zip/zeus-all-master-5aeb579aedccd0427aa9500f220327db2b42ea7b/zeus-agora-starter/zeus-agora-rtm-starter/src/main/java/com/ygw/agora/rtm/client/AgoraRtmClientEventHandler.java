package com.ygw.agora.rtm.client;

public interface AgoraRtmClientEventHandler {

    /**
     * 登录成功
     */
    void loginSuccess(String userId);

    /**
     * 正在重新登录
     */
    void reconnecting(String userId);

    /**
     * 离开
     */
    void aborted(String userId);

    /**
     * 消息发送成功
     * @param receiverId
     * @param message
     */
    void receiveMessage(String receiverId,String message);
}
