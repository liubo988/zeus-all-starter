package com.ygw.agora.rtm;

import com.ygw.agora.rtm.client.AgoraRtmClient;
import com.ygw.agora.rtm.client.AgoraRtmClientManager;
import com.ygw.agora.rtm.config.AgoraRtmConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;

@SpringBootApplication
public class AgoraRtmApplicationTests implements CommandLineRunner {

    @Autowired
    private AgoraRtmClientManager agoraRtmClientBuilder;

    public static void main(String[] args) {
        SpringApplication.run(AgoraRtmApplicationTests.class, args);
    }

    private String userIdPrefix = "teaching";
    private String userIdSuffix = "3434";

    private String addUserIdPrefixAndSuffix(String userId){
        String realUserId = userId;
        if(!StringUtils.isEmpty(userIdPrefix)){
            realUserId = userIdPrefix+realUserId;
        }

        if(!StringUtils.isEmpty(userIdSuffix)){
            realUserId = realUserId+userIdSuffix;
        }
        return realUserId;
    }
    @Override
    public void run(String... strings) throws Exception {
        String userId = "eterere";
        AgoraRtmClientManager manager =  new AgoraRtmClientManager("athena","001");
        manager.setAgoraRtmConfig(new AgoraRtmConfig());
        AgoraRtmClient a = manager.getInstance(userId,0);


        for(int i=50;i>0;i--){
            a.sendChannelMessage(i+"","hello",false);

        }

        a.loginOut();

        while (true){
//            String id = "rrrrrrrrrrr";
//            String realId = this.addUserIdPrefixAndSuffix(id);
//            System.out.println("id"+id+";realId"+realId);

        }
    }
}
