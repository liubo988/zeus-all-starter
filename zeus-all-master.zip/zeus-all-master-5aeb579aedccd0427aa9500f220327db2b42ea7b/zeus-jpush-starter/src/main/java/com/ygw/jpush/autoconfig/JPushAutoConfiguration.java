package com.ygw.jpush.autoconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import com.ygw.jpush.client.JPushClient;
import com.ygw.jpush.config.JPushConfig;
import com.ygw.jpush.service.JPushServiceImpl;

/**
 *
 */
@Configuration
@EnableConfigurationProperties(JPushConfig.class)
@ConditionalOnProperty(prefix = "jpush", value = "enabled", matchIfMissing = true)
public class JPushAutoConfiguration {

	@Autowired
	private JPushConfig jpushConfig;

	@Bean(initMethod = "init", destroyMethod = "close")
	@DependsOn({ "jpushServiceImpl" })
	JPushClient jPushClient() {
		JPushClient jpushClient = new JPushClient();
		jpushClient.setJPushConfig(jpushConfig);
		return jpushClient;
	}

	@Bean
	@ConditionalOnMissingBean(JPushServiceImpl.class)
	JPushServiceImpl jpushServiceImpl() {
		return new JPushServiceImpl();
	}
}
