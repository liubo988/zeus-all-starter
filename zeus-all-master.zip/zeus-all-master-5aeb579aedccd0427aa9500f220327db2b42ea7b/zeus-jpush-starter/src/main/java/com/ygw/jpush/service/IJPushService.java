package com.ygw.jpush.service;

import java.util.List;

import com.ygw.jpush.listener.JPushProxyListener;

public interface IJPushService {

	/**
	 * 关闭JPushClient进程
	 */
	void closeJPushClient();

	/**
	 * 
	 * send：发送消息（无监听）
	 * @param alias 别名
	 * @param msgContent 内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月7日 下午12:19:54
	 */
	void send(String alias, String msgContent);

	/**
	 * 
	 * sendTitle :按别名集合,推送标题消息给到用户(无监听)
	 * @param alias 别名
	 * @param title 标题
	 * @param msgContent 内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月7日 下午12:25:01
	 */
	void sendTitle(String alias, String title, String msgContent);

	/**
	 * 
	 * sendTitleList：按别名集合,推送标题消息给到用户(无监听)
	 * @param alias 别名
	 * @param title 标题
	 * @param msgContent 内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月7日 下午12:27:51
	 */
	void sendTitleList(List<String> alias, String title, String msgContent);

	/**
	 * 
	 * sendMessage：按别名推送消息到所有平台(无监听)
	 * @param alias    别名
	 * @param msgContent    内容
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年11月06日 下午1:15:23
	 */
	void sendMessage(String alias, String msgContent, JPushProxyListener listener);

	/**
	 * 
	 * sendTitleMessage：推送标题消息给用户
	 * @param alias 设备号
	 * @param title 标题
	 * @param msgContent 内容
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年11月06日 下午1:11:59
	 */
	void sendTitleMessage(String alias, String title, String msgContent, JPushProxyListener listener);

	/**
	 * 
	 * sendTitleMessageList：按别名集合,推送标题消息给到用户
	 * @param alias 设备号集合
	 * @param title 标题
	 * @param msgContent 内容
	 * @return
	 * @exception	
	 * @author lb
	 * @date 2011年11月06日 下午1:11:59
	 */
	void sendTitleMessageList(List<String> alias, String title, String msgContent, JPushProxyListener listener);

}
