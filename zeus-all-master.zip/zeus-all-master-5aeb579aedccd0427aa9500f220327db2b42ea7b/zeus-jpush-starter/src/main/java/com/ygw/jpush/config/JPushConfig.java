package com.ygw.jpush.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "jpush")
public class JPushConfig {
	private boolean isproduction = false;

	private String masterSecret = "26f373efc8aa6648baef3b12";

	private String appKey = "7442f22f8d87d8fd19ea0901";

	private boolean isDefault = true;

	/**
	 * @return the masterSecret
	 */
	public String getMasterSecret() {
		return masterSecret;
	}

	/**   
	 * @param masterSecret the masterSecret to set   
	 */
	public void setMasterSecret(String masterSecret) {
		this.masterSecret = masterSecret;
	}

	/**
	 * @return the appKey
	 */
	public String getAppKey() {
		return appKey;
	}

	/**   
	 * @param appKey the appKey to set   
	 */
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	/**
	 * @return the isproduction
	 */
	public boolean isIsproduction() {
		return isproduction;
	}

	/**   
	 * @param isproduction the isproduction to set   
	 */
	public void setIsproduction(boolean isproduction) {
		this.isproduction = isproduction;
	}

	/**
	 * @return the isDefault
	 */
	public boolean isDefault() {
		return isDefault;
	}

	/**   
	 * @param isDefault the isDefault to set   
	 */
	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

}
