package com.ygw.jpush.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosAlert;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

import com.ygw.jpush.config.JPushConfig;
import com.ygw.jpush.listener.JPushProxyListener;

public class JPushServiceImpl implements IJPushService {

	private static final Logger log = LoggerFactory.getLogger(JPushServiceImpl.class);

	/************************************/

	/************************************/
	private boolean production = true;

	// 极光推送测试环境
	public static final String JPUSH_SOUND = "default";

	/**
	 * PushResult返回状态码，0为成功
	 */
	private static final int SUCCESS = 0;

	private JPushClient jpushClient = null;

	public JPushServiceImpl() {

	}

	public JPushServiceImpl(JPushConfig jpushConfig) {
		jpushClient = new JPushClient(jpushConfig.getMasterSecret(), jpushConfig.getAppKey());
	}

	@Override
	public void send(String alias, String msgContent) {
		try {
			PushPayload payload = buildPushAlias(alias, null, msgContent);
			jpushClient.sendPush(payload);
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
		} catch (APIRequestException e) {
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());
		} finally {
			closeJPushClient();
		}
	}

	@Override
	public void sendTitle(String alias, String title, String msgContent) {
		try {
			PushPayload payload = buildPushAlias(alias, title, msgContent);
			jpushClient.sendPush(payload);
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
		} catch (APIRequestException e) {
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());

		} finally {
			closeJPushClient();
		}
	}

	@Override
	public void sendTitleList(List<String> alias, String title, String msgContent) {
		try {
			PushPayload payload = buildPushAliasList(alias, title, msgContent);
			jpushClient.sendPush(payload);
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
		} catch (APIRequestException e) {
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());
		} finally {
			closeJPushClient();
		}

	}

	// 所有平台，推送目标是别名
	public void sendMessage(String alias, String msgContent, JPushProxyListener listener) {
		try {
			PushPayload payload = buildPushAlias(alias, null, msgContent);
			PushResult result = jpushClient.sendPush(payload);
			if (result.statusCode == SUCCESS) {
				listener.pushSuccess(result.statusCode);
			}
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
			// listener.connectionFailed(e);
		} catch (APIRequestException e) {
			listener.pushFailed(e);
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());
		} finally {
			closeJPushClient();
		}
	}

	/**
	* 推送消息给用户
	* @param alias 别名
	* @param title 标题
	* @param msgContent 内容
	*/
	public void sendTitleMessage(String alias, String title, String msgContent, JPushProxyListener listener) {
		try {
			PushPayload payload = buildPushAlias(alias, title, msgContent);
			PushResult result = jpushClient.sendPush(payload);
			if (result.statusCode == SUCCESS) {
				listener.pushSuccess(result.statusCode);
			}
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
			// listener.connectionFailed(e);
		} catch (APIRequestException e) {
			listener.pushFailed(e);
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());
		} finally {
			closeJPushClient();
		}
	}

	/**
	* 推送消息给给指定用户集合
	* @param alias 别名集合
	* @param title 标题
	* @param msgContent 内容
	*/
	public void sendTitleMessageList(List<String> alias, String title, String msgContent, JPushProxyListener listener) {
		try {
			PushPayload payload = buildPushAliasList(alias, title, msgContent);
			PushResult result = jpushClient.sendPush(payload);
			if (result.statusCode == SUCCESS) {
				listener.pushSuccess(result.statusCode);
			}
		} catch (APIConnectionException e) {
			log.error("========jpush--连接超时消息报错:{} ====== ", e.getMessage());
			// listener.connectionFailed(e);
		} catch (APIRequestException e) {
			listener.pushFailed(e);
			log.error("========jpush--推送报错:{} ====== ", e.getMessage());
		} finally {
			closeJPushClient();
		}
	}

	/**
	 * 关闭JPushClient进程
	 */
	public void closeJPushClient() {
		if (jpushClient != null) {
			log.warn("=======JPushClient 关闭了 ====== ");
			jpushClient.close();
		}
	}

	/*************************************************************私有公用方法开始**************************************************************************************/
	PushPayload buildPushAlias(String alias, String title, String alert) {
		if (StringUtils.isEmpty(title)) {// 不带标题的消息
			return PushPayload
					.newBuilder()
					.setPlatform(Platform.android_ios())
					.setAudience(Audience.alias(alias))
					.setNotification(
							Notification.newBuilder()
									.addPlatformNotification(AndroidNotification.newBuilder().addExtra("type", "infomation").setAlert(alert).build())
									.addPlatformNotification(IosNotification.newBuilder().addExtra("type", "infomation").setAlert(alert).build())
									.build()).setOptions(Options.newBuilder().setApnsProduction(production).build()).build();
		}
		IosAlert alertStr = IosAlert.newBuilder().setTitleAndBody(title, null, alert).setActionLocKey("PLAY").build();
		return PushPayload
				.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.alias(alias))
				.setNotification(
						Notification
								.newBuilder()
								.addPlatformNotification(
										IosNotification.newBuilder().setAlert(alertStr).incrBadge(1).setSound(JPUSH_SOUND).addExtras(null).build())
								.addPlatformNotification(AndroidNotification.newBuilder().setAlert(alert).setTitle(title).build()).build())
				.setMessage(Message.content(alert)).setOptions(Options.newBuilder().setApnsProduction(production).build()).build();
	}

	PushPayload buildPushAliasList(List<String> alias, String title, String msgContent) {
		return PushPayload
				.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.alias(alias))
				.setNotification(
						Notification
								.newBuilder()
								.addPlatformNotification(
										IosNotification.newBuilder().setAlert(title).incrBadge(1).setSound(JPUSH_SOUND).addExtra("from", "JPush")
												.build())
								.addPlatformNotification(AndroidNotification.newBuilder().setAlert(title).setTitle(msgContent).build()).build())
				.setMessage(Message.content(msgContent)).setOptions(Options.newBuilder().setApnsProduction(production).build()).build();
	}

	/**************************************************************私有公用方法开始结束*************************************************************************************/

}
