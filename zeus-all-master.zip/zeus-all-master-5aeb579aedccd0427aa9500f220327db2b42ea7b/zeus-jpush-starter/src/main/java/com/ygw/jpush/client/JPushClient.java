package com.ygw.jpush.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ygw.jpush.config.JPushConfig;
import com.ygw.jpush.listener.JPushProxyListener;
import com.ygw.jpush.service.IJPushService;
import com.ygw.jpush.service.JPushServiceImpl;

public class JPushClient {

	private static final Logger log = LoggerFactory.getLogger(JPushClient.class);

	private IJPushService jPushService;

	@Autowired
	private JPushConfig jpushConfig;

	/**
	 * 初始化IJPushService
	 */
	public void init() {
		if (jPushService == null) {
			log.warn("=======JPushClient 启动了 ====== ");
			this.jPushService = new JPushServiceImpl(jpushConfig);
		}
	}

	/**
	 * 关闭JPushClient进程
	 */
	public void close() {
		if (jPushService != null) {
			log.warn("=======JPushClient 关闭了 ====== ");
			this.jPushService.closeJPushClient();
		}
	}

	/**
	 * 
	 * send：按别名推送消息给用户(无监听)
	 * @param alias 别名（设备号）
	 * @param msgContent 消息内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void send(String alias, String msgContent) {
		init();
		this.jPushService.send(alias, msgContent);
	}

	/**
	 * 
	 * send：按别名推送消息给用户
	 * @param alias 别名（设备号）
	 * @param msgContent 消息内容
	 * @param listener   推送代理监听器
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void send(String alias, String msgContent, JPushProxyListener listener) {
		init();
		this.jPushService.sendMessage(alias, msgContent, listener);
	}

	/**
	 * 
	 * sendTitle：按别名推送标题消息给用户（无监听）
	 * @param alias 别名（设备号）
	 * @param title 标题
	 * @param msgContent 消息内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void sendTitleMessage(String alias, String title, String msgContent) {
		init();
		this.jPushService.sendTitle(alias, title, msgContent);
	}

	/**
	 * 
	 * sendTitleMessage：按别名推送标题消息给用户
	 * @param alias 别名（设备号）
	 * @param title 标题
	 * @param msgContent 消息内容
	 * @param listener   推送代理监听器
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void sendTitleMessage(String alias, String title, String msgContent, JPushProxyListener listener) {
		init();
		this.jPushService.sendTitleMessage(alias, title, msgContent, listener);
	}

	/**
	 * 
	 * sendTitleMessageList：推送标题消息给指定别名集合（无监听）
	 * @param alias 别名集合（设备号集合）
	 * @param title 标题
	 * @param msgContent 消息内容
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void sendTitleMessageList(List<String> alias, String title, String msgContent) {
		init();
		jPushService.sendTitleList(alias, title, msgContent);
	}

	/**
	 * 
	 * sendTitleMessageList：推送标题消息给指定别名集合
	 * @param alias 别名集合（设备号集合）
	 * @param title 标题
	 * @param msgContent 消息内容
	 * @param listener   推送代理监听器
	 * @exception	
	 * @author bobo
	 * @date 2019年11月6日 下午3:34:28
	 */
	public void sendTitleMessageList(List<String> alias, String title, String msgContent, JPushProxyListener listener) {
		init();
		jPushService.sendTitleMessageList(alias, title, msgContent, listener);
	}

	public void setJPushConfig(JPushConfig jpushConfig) {
		this.jpushConfig = jpushConfig;
	}

}
