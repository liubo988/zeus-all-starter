package com.ygw.jpush.listener;

import cn.jiguang.common.resp.APIRequestException;

public interface JPushProxyListener {

	/**
	 * 推送成功
	 *
	 * @param statusCode 状态码	
	 */
	void pushSuccess(int statusCode);

	/**
	 * 推送，连接失败
	 *
	 * @param e
	 */
	// void connectionFailed(APIConnectionException e);

	/**
	 * 推送失败
	 *
	 * @param e
	 */
	void pushFailed(APIRequestException e);

}
