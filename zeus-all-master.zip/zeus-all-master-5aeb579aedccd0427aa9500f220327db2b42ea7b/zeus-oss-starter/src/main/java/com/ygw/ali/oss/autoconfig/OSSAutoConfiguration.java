package com.ygw.ali.oss.autoconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import com.aliyun.oss.OSSClientBuilder;
import com.ygw.ali.oss.client.OSSClient;
import com.ygw.ali.oss.config.OSSConfig;

/**
 *
 */
@Configuration
@EnableConfigurationProperties(OSSConfig.class)
@ConditionalOnProperty(prefix = "ali.oss", value = "enabled", matchIfMissing = true)
public class OSSAutoConfiguration {

	@Autowired
	private OSSConfig ossConfig;

	@Bean(initMethod = "init", destroyMethod = "shutdown")
	@DependsOn({ "ossClientBuilder" })
	OSSClient ossClient() {
		OSSClient ossClient = new OSSClient();
		ossClient.setOssConfig(ossConfig);
		return ossClient;
	}

	@Bean
	@ConditionalOnMissingBean(OSSClientBuilder.class)
	OSSClientBuilder ossClientBuilder() {
		return new OSSClientBuilder();

	}
}
