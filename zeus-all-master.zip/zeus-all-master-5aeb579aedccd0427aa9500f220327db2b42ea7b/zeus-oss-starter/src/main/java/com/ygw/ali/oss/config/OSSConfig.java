package com.ygw.ali.oss.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "ali.oss")
public class OSSConfig {
	private String endpoint = "https://oss-cn-shanghai-internal.aliyuncs.com";
	// accessKey
	private String accessKeyId = "LTAIlYB9e7u2WG9R";
	private String accessKeySecret = "bSQ0lZmpPRHwYPFTjzEzbBQHVljTtI";
	// 空间
	private String bucketName = "ygwfile";
	// 文件存储目录
	private String filedir = "teaching/";

	/**
	 * @return the endpoint
	 */
	public String getEndpoint() {
		return endpoint;
	}

	/**   
	 * @param endpoint the endpoint to set   
	 */
	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	/**
	 * @return the accessKeyId
	 */
	public String getAccessKeyId() {
		return accessKeyId;
	}

	/**   
	 * @param accessKeyId the accessKeyId to set   
	 */
	public void setAccessKeyId(String accessKeyId) {
		this.accessKeyId = accessKeyId;
	}

	/**
	 * @return the accessKeySecret
	 */
	public String getAccessKeySecret() {
		return accessKeySecret;
	}

	/**   
	 * @param accessKeySecret the accessKeySecret to set   
	 */
	public void setAccessKeySecret(String accessKeySecret) {
		this.accessKeySecret = accessKeySecret;
	}

	/**
	 * @return the bucketName
	 */
	public String getBucketName() {
		return bucketName;
	}

	/**   
	 * @param bucketName the bucketName to set   
	 */
	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	/**
	 * @return the filedir
	 */
	public String getFiledir() {
		return filedir;
	}

	/**   
	 * @param filedir the filedir to set   
	 */
	public void setFiledir(String filedir) {
		this.filedir = filedir;
	}
}
