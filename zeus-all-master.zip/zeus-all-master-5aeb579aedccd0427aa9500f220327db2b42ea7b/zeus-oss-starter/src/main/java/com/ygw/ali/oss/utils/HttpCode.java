package com.ygw.ali.oss.utils;

/**
 * @author lb
 */
public enum HttpCode {
    /**
     * 200请求成功
     */
    OK(200),
    /**
     * 400参数不正确
     */
    BAD_REQUEST(400),
    /**
     * 201未查到数据
     */
    NO_DATA(201),
    /**
     * 401没有登录
     */
    UNAUTHORIZED(401),
    /**
     * 403没有权限
     */
    FORBIDDEN(403),
    /**
     * 404找不到页面
     */
    NOT_FOUND(404),
    /**
     * 408请求超时
     */
    REQUEST_TIMEOUT(408),
    /**
     * 409发生冲突
     */
    CONFLICT(409),
    /**
     * 410已被删除
     */
    GONE(410),
    /**
     * 423已被锁定
     */
    LOCKED(423),
    /**
     * 500服务器出错
     */
    INTERNAL_SERVER_ERROR(500),


    /**
     * 502 订单可支付
     */
    CAN_PAY(502),
    /**
     * 503 无效订单
     */
    INVALID_ORDER(503),
    /**
     * 504 已支付订单
     */
    DO_NOT_PAY_ORDER(504),
    /**
     * 507 班级人数已满
     */
    CLASS_FULL(507),

    /**
     * 508 声网视频重复录制
     */
    REPEAT_RECORD(508),

    FILE_OVERSIZE(1001); // 文件大小超出

    private final Integer value;

    HttpCode(Integer value) {
        this.value = value;
    }

    /**
     * Return the integer value of this status code.
     */
    public Integer value() {
        return this.value;
    }

    public String msg() {
        String msg = "";
        switch (this.value) {
            case 200:
                msg = "请求成功！";
                break;
            case 201:
                msg = "未查到数据！";
                break;
            case 400:
                msg = "请求参数出错！";
                break;
            case 401:
                msg = "没有登录！";
                break;
            case 403:
                msg = "没有权限！";
                break;
            case 404:
                msg = "请求无法到达！";
                break;
            case 408:
                msg = "请求超时！";
                break;
            case 409:
                msg = "发生冲突！";
                break;
            case 410:
                msg = "已被删除！";
                break;
            case 423:
                msg = "已被锁定！";
                break;
            case 500:
                msg = "服务器内部错误！";
                break;

            case 502:
                msg = "订单可支付！";
                break;
            case 503:
                msg = "无效订单！";
                break;
            case 504:
                msg = "订单不可支付！";
                break;
            case 507:
                msg = "班级人数已满！";
                break;


            case 1001:
                msg = "文件过大";
                break;


            default:
                msg = "未知异常！";
                break;
        }
        return msg;
    }

    public String toString() {
        return this.value.toString();
    }
}
