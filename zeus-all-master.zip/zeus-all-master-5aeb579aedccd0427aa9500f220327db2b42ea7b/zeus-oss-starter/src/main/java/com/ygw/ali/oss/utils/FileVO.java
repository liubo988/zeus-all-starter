package com.ygw.ali.oss.utils;

import lombok.Data;

/**
 * Title : FileVO
 * Description: 类描述
 * Copyright (c) 2019
 * Company: 上海阳光喔科技有限公司
 * 修改人: zlp
 * 修改时间: 2019年07月13日 14:33
 * 修改备注:
 * @author zlp
 * @version 1.0
 * @date 2019年07月13日 14:33
 */
@Data
public class FileVO {

    private String fileUrl;
    /**
     * 1视频，2图片，3文件，4音频
     */
    private Integer fileType;
    /**
     * 附件名称
     */
    private String fileName;
    /**
     * 附件后缀
     */
    private String fileSuffix;
    /**
     * 视频封面图
     */
    private String videoCover;
    /**
     * 时长（秒）
     */
    private Integer duration;


    public FileVO(String fileUrl, Integer fileType, String fileSuffix, String videoCover) {
        this.fileUrl = fileUrl;
        this.fileType = fileType;
        this.fileSuffix = fileSuffix;
        this.videoCover = videoCover;
    }

    public FileVO() {
    }
}
