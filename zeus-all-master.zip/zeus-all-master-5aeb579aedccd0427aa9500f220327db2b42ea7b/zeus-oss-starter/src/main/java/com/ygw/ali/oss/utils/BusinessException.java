package com.ygw.ali.oss.utils;

public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = -4526124050112907054L;

	private Object httpCode;

	public BusinessException(String msg) {
		super(msg);
	}

	public BusinessException(HttpCode httpCode) {
		super(httpCode.msg());
		this.httpCode = httpCode;
	}

	public BusinessException(String msg, Integer code) {
		super(msg);
		this.httpCode = code;
	}

	/**
	 * @return the httpCode
	 */
	public Object getHttpCode() {
		return httpCode;
	}

	/**   
	 * @param httpCode the httpCode to set   
	 */
	public void setHttpCode(Object httpCode) {
		this.httpCode = httpCode;
	}

}
