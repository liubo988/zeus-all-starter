package com.ygw.ali.oss.client;

import com.aliyun.oss.ClientBuilderConfiguration;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.DeleteObjectsRequest;
import com.aliyun.oss.model.GenericRequest;
import com.aliyun.oss.model.GetObjectRequest;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyun.oss.model.PutObjectResult;
import com.ygw.ali.oss.config.OSSConfig;
import com.ygw.ali.oss.utils.BusinessException;
import com.ygw.ali.oss.utils.FileVO;
import com.ygw.ali.oss.utils.HttpCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * <p>Title: OSSClientBean </p>
 * <p>Description: oss处理工具类</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年11月4日 下午2:25:19</p>
 * <p>修改备注：</p>
 * @date 2019年11月4日 下午2:25:19
 */
public class OSSClient {

    private static final Logger log = LoggerFactory.getLogger(OSSClient.class);

    @Autowired
    private OSSConfig ossConfig;

    private OSSClientBuilder clientBuilder;

    // 拼接视频第一帧
    private String COVER_SUFFIX = "?x-oss-process=video/snapshot,t_1,m_fast";

    private static ThreadLocal<OSS> ossMap = new ThreadLocal<>();

    public void setOssConfig(OSSConfig ossConfig) {
        this.ossConfig = ossConfig;
    }

    /**
     * 初始化
     */
    public void init() {
        if (clientBuilder == null) {
            clientBuilder = new OSSClientBuilder();
        }
        ClientBuilderConfiguration conf = new ClientBuilderConfiguration();
        conf.setSocketTimeout(100 * 1000);
        log.info("==============ossClient初始化了==============");
        OSS oss = clientBuilder.build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret(), conf);
        ossMap.set(oss);
    }

    /**
     * 销毁
     */
    public void shutdown() {
        log.info("==============ossClient销毁了==============");
        if (!ObjectUtils.isEmpty(ossMap)) {
            ossMap.get().shutdown();
        }
    }

    /**
     * uploadImg2Oss：上传本地图片
     *
     * @param file    文件
     * @param fileDir 指定目录
     * @return
     * @throws Exception
     * @throws
     * @author bobo
     * @date 2019年11月4日 下午6:02:29
     */
    public String upload(MultipartFile file, String fileDir) throws Exception {
        init();
        String originalFilename = file.getOriginalFilename();
        String substring = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();
        Random random = new Random();
        String name = random.nextInt(10000) + System.currentTimeMillis() + substring;
        // 文件大小处理
        this.postTooBig(file, substring);
        try {
            InputStream inputStream = file.getInputStream();
            this.uploadFileHandler(inputStream, name, this.spliceFileDir(fileDir));
            if (!StringUtils.isEmpty(name)) {
                String[] split = name.split("/");
                String url = this.getUrl(this.spliceFileDir(fileDir) + split[split.length - 1]);
                if (url != null && url.contains("-internal")) {
                    url = url.replaceAll("-internal", "");
                }
                String[] strings = url.split("\\?");
                this.shutdown();
                return strings[0];
            }
            return null;
        } catch (Exception e) {
            throw new Exception("图片上传失败");
        }

    }

    /**
     * uploadImg2Oss：上传本地图片到默认文件夹
     *
     * @param file
     * @return
     * @throws Exception
     * @throws
     * @author bobo
     * @date 2019年11月4日 下午6:02:29
     */
    public String upload(MultipartFile file) throws Exception {
        init();
        String originalFilename = file.getOriginalFilename();
        String substring = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();
        Random random = new Random();
        String name = random.nextInt(10000) + System.currentTimeMillis() + substring;
        // 文件大小处理
        this.postTooBig(file, substring);
        try {
            InputStream inputStream = file.getInputStream();
            this.uploadFileHandler(inputStream, name, ossConfig.getFiledir());
            if (!StringUtils.isEmpty(name)) {
                String[] split = name.split("/");
                String url = this.getUrl(ossConfig.getFiledir() + split[split.length - 1]);
                if (url != null && url.contains("-internal")) {
                    url = url.replaceAll("-internal", "");
                }
                String[] strings = url.split("\\?");
                this.shutdown();
                return strings[0];
            }
            return null;
        } catch (Exception e) {
            throw new Exception("图片上传失败");
        }
    }

    /**
     * upload：上传流文件到阿里云指定目录
     *
     * @param inputStream 输入流
     * @param file        文件名称
     * @param fileDir     文件夹
     * @return
     * @throws Exception
     * @throws
     * @author bobo
     * @date 2019年11月4日 下午6:02:29
     */
    public String upload(InputStream inputStream, String fileName, String fileDir) throws Exception {
        init();
        try {
            this.uploadFileHandler(inputStream, fileName, this.spliceFileDir(fileDir));
            if (!StringUtils.isEmpty(fileName)) {
                String[] split = fileName.split("/");
                String url = this.getUrl(this.spliceFileDir(fileDir) + split[split.length - 1]);
                if (url != null && url.contains("-internal")) {
                    url = url.replaceAll("-internal", "");
                }
                String[] strings = url.split("\\?");
                this.shutdown();
                return strings[0];
            }
            return null;
        } catch (Exception e) {
            throw new Exception("图片上传失败");
        }
    }

    /**
     * uploadNetWorkImg：上传网络图片
     *
     * @param url
     * @return
     * @throws IOException
     * @throws
     * @author bobo
     * @date 2019年11月4日 下午6:05:10
     */
    public String uploadNetWorkImg(String url) throws Exception {
        String substring = url.substring(url.lastIndexOf(".")).toLowerCase();
        Random random = new Random();
        String name = random.nextInt(10000) + System.currentTimeMillis() + substring;
        try {
            // 上传网络流。
            InputStream inputStream = new URL(url).openStream();
            this.uploadNetWorkHandler(inputStream, name);
            this.shutdown();
            return name;
        } catch (FileNotFoundException e) {
            throw new Exception("图片上传失败");
        }
    }

    /**
     * findUploadFileList：查询上传文件集合
     *
     * @param files 上传文件列表
     * @return List<FileVO>
     * @throws Exception
     * @throws
     * @author bobo
     * @date 2019年11月28日 下午3:34:55
     */
    public List<FileVO> findUploadFileList(MultipartFile[] files) throws Exception {
        if (files != null && files.length > 0) {
            List<FileVO> list = new ArrayList<>();
            for (MultipartFile multipartFile : files) {
                FileVO vo = findUploadFile(multipartFile);
                list.add(vo);
            }
            return list;
        }
        return null;
    }

    /**
     * findUploadFile：获取单个上传文件对象
     *
     * @param multipartFile 上传文件
     * @return FileVO
     * @throws Exception
     * @throws
     * @author bobo
     * @date 2019年11月28日 下午3:38:38
     */
    public FileVO findUploadFile(MultipartFile multipartFile) throws Exception {
        if (multipartFile == null) {
            return null;
        }
        String fileSuffix = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf('.') + 1);
        String imgUrl = this.upload(multipartFile);
        // 获取文件类型 1:视频，2:图片，3:文件，4:音频
        int fileType = this.getFileType(fileSuffix);
        FileVO fileVO = new FileVO(imgUrl, fileType, fileSuffix, fileType == 1 ? imgUrl + this.COVER_SUFFIX : null);
        String fileName = multipartFile.getOriginalFilename();
        fileVO.setFileName(fileName);
        return fileVO;
    }

    private String uploadNetWorkHandler(InputStream inputStream, String fileName) {
        String ret = "";
        try {
            // 创建上传Object的Metadata
            ObjectMetadata objectMetadata = new ObjectMetadata();
            objectMetadata.setContentType(this.getContentType(fileName.substring(fileName.lastIndexOf("."))));
            if (!fileName.contains(".png") && !fileName.contains(".jpg") && !fileName.contains(".jpeg") && !fileName.contains(".gif") && !fileName.contains(".bmp")) {
                objectMetadata.setContentDisposition("attachment;filename=" + fileName);
            } else {
                objectMetadata.setCacheControl("no-cache");
            }
            try {
                PutObjectResult putResult = ossMap.get().putObject(ossConfig.getBucketName(), ossConfig.getFiledir() + fileName, inputStream, objectMetadata);
                ret = putResult.getETag();
            } catch (Exception e) {
                log.error(e.toString(), e);
            }
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    private String uploadFileHandler(InputStream inputStream, String fileName, String fileDir) {
        String ret = "";
        try {
            // 创建上传Object的Metadata
            ObjectMetadata objectMetadata = new ObjectMetadata();
            if (!fileName.contains(".png") && !fileName.contains(".jpg") && !fileName.contains(".jpeg") && !fileName.contains(".gif") && !fileName.contains(".bmp")) {
                objectMetadata.setContentDisposition("attachment;filename=" + fileName);
            } else {
                objectMetadata.setCacheControl("no-cache");
            }
            objectMetadata.setContentType(this.getContentType(fileName.substring(fileName.lastIndexOf("."))));
            // 上传文件
            PutObjectResult putResult = ossMap.get().putObject(ossConfig.getBucketName(), fileDir + fileName, inputStream, objectMetadata);
            ret = putResult.getETag();
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    /**
     * downloadFile：下载文件
     *
     * @param fileUrl 指定文件地址，全路径
     * @param newFileName  指定新文件名称
     * @throws
     * @author bobo
     * @date 2019年11月21日 下午5:04:08
     */
    /*public void downloadFile(String fileUrl, String newFileName) {
        init();
        if ("/".startsWith(fileUrl)) {
            fileUrl = fileUrl.substring(1);
        }
        File localFile = new File(newFileName);
        try {
            // 下载文件
            ossMap.get().getObject(new GetObjectRequest(ossConfig.getBucketName(), fileUrl), localFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("下载失败", e);
        } finally {
            this.shutdown();
        }
    }*/

    /**
     * downloadFile：下载文件
     *
     * @param fileUrl 指定文件地址，全路径
     * @param newFileName  指定新文件名称
     * @throws
     * @author bobo
     * @date 2019年11月21日 下午5:04:08
     */
    public void downloadFile(HttpServletResponse response, String fileUrl, String newFileName) {
        init();
        try {
            if ("/".startsWith(fileUrl)) {
                fileUrl = fileUrl.substring(1);
            }
            OSSObject ossObject = ossMap.get().getObject(new GetObjectRequest(ossConfig.getBucketName(), fileUrl));
            // 读去Object内容  返回
            BufferedInputStream in = new BufferedInputStream(ossObject.getObjectContent());
            BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
            // 通知浏览器以附件形式下载
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(newFileName, "utf-8"));
            byte[] car = new byte[1024];
            int L = 0;
            while ((L = in.read(car)) != -1) {
                out.write(car, 0, L);
            }
            out.flush();
            out.close();
            in.close();

            this.shutdown();
        } catch (IOException e) {
            e.printStackTrace();
            log.error("下载失败", e);
        }
    }

    /**
     * 获得url链接
     *
     * @param key
     * @return
     */
    public String getUrl(String key) {
        // 设置URL过期时间为10年 3600l* 1000*24*365*10
        Date expiration = new Date(System.currentTimeMillis() + 3600L * 1000 * 24 * 365 * 10);
        // 生成URL
        URL url = ossMap.get().generatePresignedUrl(ossConfig.getBucketName(), key, expiration);
        // url.getProtocol()
        if (url != null) {
            String urlStr = url.toString();
            if (urlStr != null && urlStr.contains("-internal")) {
                urlStr = urlStr.replaceAll("-internal", "");
            }
            return urlStr;
        }
        return null;
    }

    /**
     * @param fileUrl 需要删除的文件url
     * @return boolean 是否删除成功
     * @MethodName: deleteFile
     * @Description: 单文件删除
     */
    public boolean deleteFile(String fileUrl) {
        init();
        try {
            GenericRequest request = new DeleteObjectsRequest(ossConfig.getBucketName()).withKey(fileUrl);
            ossMap.get().deleteObject(request);
        } catch (Exception oe) {
            oe.printStackTrace();
            return false;
        } finally {
            this.shutdown();
        }
        return true;
    }

    /**
     * createBucket：创建存储桶
     *
     * @param bucketName 要创建的空间名称
     * @throws
     * @author bobo
     * @date 2019年11月5日 下午5:11:06
     */
    public void createBucket(String bucketName) {
        try {
            // 创建OSSClient实例。
            OSS ossClient = clientBuilder.build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
            // 创建存储空间。
            ossClient.createBucket(bucketName);
            // 关闭OSSClient。
            this.shutdown();
        } catch (Exception e) {
            log.error("创建bucket失败：{}", e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Description: 判断OSS服务文件上传时文件的contentType
     *
     * @param filenameExtension 文件后缀
     * @return String
     */
    private static String getContentType(String filenameExtension) {
        if (filenameExtension.equalsIgnoreCase(".bmp")) {
            return "image/bmp";
        }
        if (filenameExtension.equalsIgnoreCase(".gif")) {
            return "image/gif";
        }
        if (filenameExtension.equalsIgnoreCase(".jpeg") || filenameExtension.equalsIgnoreCase(".jpg") || filenameExtension.equalsIgnoreCase(".png")) {
            return "image/jpeg";
        }
        if (filenameExtension.equalsIgnoreCase(".html")) {
            return "text/html";
        }
        if (filenameExtension.equalsIgnoreCase(".txt")) {
            return "text/plain";
        }
        if (filenameExtension.equalsIgnoreCase(".vsd")) {
            return "application/vnd.+";
        }
        if (filenameExtension.equalsIgnoreCase(".pptx") || filenameExtension.equalsIgnoreCase(".ppt")) {
            return "application/vnd.ms-powerpoint";
        }
        if (filenameExtension.equalsIgnoreCase(".docx") || filenameExtension.equalsIgnoreCase(".doc")) {
            return "application/msword";
        }
        if (filenameExtension.equalsIgnoreCase(".xml")) {
            return "text/xml";
        }
        if (filenameExtension.equalsIgnoreCase(".mp4")) {
            return "video/mpeg4";
        }
        if (filenameExtension.equalsIgnoreCase(".xls")) {
            return "application/vnd.ms-excel";
        }
        if (filenameExtension.equalsIgnoreCase(".xlsx")) {
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        if (filenameExtension.equalsIgnoreCase(".pdf")) {
            return "application/pdf";
        }
        if (filenameExtension.equalsIgnoreCase(".mp3")) {
            return "audio/mp3";
        }
        if (filenameExtension.equalsIgnoreCase(".wav")) {
            return "audio/wav";
        }
        if (filenameExtension.equalsIgnoreCase(".mov")) {
            return "video/mov";
        }
        return "image/jpeg";
    }

    /**
     * 文件过大处理
     *
     * @param file
     * @param substring
     */
    private void postTooBig(MultipartFile file, String substring) {
        if (substring.equalsIgnoreCase(".mp4") && file.getSize() > 524288000) { // 视频控制在500M以内
            throw new BusinessException("文件过大，请控制在500M以内", HttpCode.FILE_OVERSIZE.value());
        } else if ((substring.equalsIgnoreCase(".docx") || substring.equalsIgnoreCase(".doc")) && file.getSize() > 31457280) { // 文件控制在30M以内
            throw new BusinessException("文件过大，请控制在30M以内", HttpCode.FILE_OVERSIZE.value());
        } else if (substring.equalsIgnoreCase(".pdf") && file.getSize() > 31457280) { // 文件控制在30M以内
            throw new BusinessException("文件过大，请控制在30M以内", HttpCode.FILE_OVERSIZE.value());
        } else if ((substring.equalsIgnoreCase(".xls") || substring.equalsIgnoreCase(".xlsx")) && file.getSize() > 31457280) { // 文件控制在30M以内
            throw new BusinessException("文件过大，请控制在30M以内", HttpCode.FILE_OVERSIZE.value());
        } else if ((substring.equalsIgnoreCase(".pptx") || substring.equalsIgnoreCase(".ppt")) && file.getSize() > 31457280) { // 文件控制在30M以内
            throw new BusinessException("文件过大，请控制在30M以内", HttpCode.FILE_OVERSIZE.value());
        } else if ((substring.equalsIgnoreCase(".jpeg") || substring.equalsIgnoreCase(".jpg") || substring.equalsIgnoreCase(".png")) && file.getSize() > 31457280) { // 图片控制在5M以内
            throw new BusinessException("文件过大，请控制在5M以内", HttpCode.FILE_OVERSIZE.value());
        } else if (substring.equalsIgnoreCase(".mp3") && file.getSize() > 31457280) { // 音频控制在30M以内
            throw new BusinessException("文件过大，请控制在30M以内", HttpCode.FILE_OVERSIZE.value());
        }
    }

    /**
     * getFileType：获取文件类型
     *
     * @param fileSuffix 文件后缀
     * @return 1:视频，2:图片，3:文件，4:音频
     * @throws
     * @author bobo
     * @date 2019年11月28日 下午3:29:54
     */
    private static int getFileType(String fileSuffix) {
        if ("jpg".equalsIgnoreCase(fileSuffix) || "jpeg".equalsIgnoreCase(fileSuffix) || "png".equalsIgnoreCase(fileSuffix)
                || "gif".equalsIgnoreCase(fileSuffix) || "bmp".equalsIgnoreCase(fileSuffix)) {
            return 2;
        } else if ("ppt".equalsIgnoreCase(fileSuffix) || "pptx".equalsIgnoreCase(fileSuffix) || "doc".equalsIgnoreCase(fileSuffix)
                || "docx".equalsIgnoreCase(fileSuffix) || "xlsx".equalsIgnoreCase(fileSuffix) || "xls".equalsIgnoreCase(fileSuffix)
                || "pdf".equalsIgnoreCase(fileSuffix)) {
            return 3;
        } else if ("mp4".equalsIgnoreCase(fileSuffix) || "mov".equalsIgnoreCase(fileSuffix) || "avi".equalsIgnoreCase(fileSuffix)
                || "3gp".equalsIgnoreCase(fileSuffix) || "rmvb".equalsIgnoreCase(fileSuffix)) {
            return 1;
        } else if ("mp3".equalsIgnoreCase(fileSuffix) || "amr".equalsIgnoreCase(fileSuffix) || "wav".equalsIgnoreCase(fileSuffix)
                || "flac".equalsIgnoreCase(fileSuffix) || "ape".equalsIgnoreCase(fileSuffix) || "aac".equalsIgnoreCase(fileSuffix)) {
            return 4;
        } else {
            return 0;
        }
    }

    /**
     * spliceFileDir: 拼接文件地址
     *
     * @param fileDir 需要拼接的目录
     * @return: java.lang.String
     * @Author: hwq
     * @Date: 2020年04月10日 18:13
     */
    private String spliceFileDir(String fileDir) {
        if (StringUtils.isEmpty(fileDir)) {
            return ossConfig.getFiledir();
        }
        if (fileDir.lastIndexOf("/") == fileDir.length() - 1) {
            return ossConfig.getFiledir() + fileDir;
        }
        return fileDir + "/";
    }

    /**
     * @return the clientBuilder
     */
    public OSSClientBuilder getClientBuilder() {
        return clientBuilder;
    }

    /**
     * @param clientBuilder the clientBuilder to set
     */
    public void setClientBuilder(OSSClientBuilder clientBuilder) {
        this.clientBuilder = clientBuilder;
    }

}
