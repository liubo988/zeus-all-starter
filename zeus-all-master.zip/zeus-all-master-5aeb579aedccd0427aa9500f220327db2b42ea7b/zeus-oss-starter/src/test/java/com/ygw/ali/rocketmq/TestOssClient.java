package com.ygw.ali.rocketmq;

import java.io.File;
import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ygw.ali.oss.client.OSSClient;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { TestOssClient.class })
public class TestOssClient {

	@Autowired
	private OSSClient ossClient;

	@Test
	public void test1() throws IOException {
		//ossClient.downloadFile("", "admin/dev/1573182073186.jpg", new File("/home/zane/logs/" + "1.jpg"));
	}
}
