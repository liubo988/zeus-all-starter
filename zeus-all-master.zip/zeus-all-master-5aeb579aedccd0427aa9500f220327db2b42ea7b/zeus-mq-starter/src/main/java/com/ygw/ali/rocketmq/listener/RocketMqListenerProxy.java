package com.ygw.ali.rocketmq.listener;

import com.aliyun.openservices.ons.api.Admin;
import com.aliyun.openservices.ons.api.MessageListener;
import com.aliyun.openservices.ons.api.PropertyKeyConst;
import com.aliyun.openservices.ons.api.batch.BatchMessageListener;
import com.aliyun.openservices.ons.api.bean.BatchConsumerBean;
import com.aliyun.openservices.ons.api.bean.ConsumerBean;
import com.aliyun.openservices.ons.api.bean.OrderConsumerBean;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.aliyun.openservices.ons.api.order.MessageOrderListener;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.builder.BatchConsumerBeanBuilder;
import com.ygw.ali.rocketmq.listener.builder.NormalConsumerBeanBuilder;
import com.ygw.ali.rocketmq.listener.builder.OrderConsumerBeanBuilder;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class RocketMqListenerProxy {


    private String topic;

    private String group;

    private Set<String> tagList = new HashSet<>();


    private Boolean isBatch;

    private Boolean isOrderly;


    private MqConfig mqConfig;

    private Integer consumeThreadNums;


    private Map<String,RocketMqMessageHandler> rocketMqMessageHandlerMap = new HashMap<>();

    private Admin admin;


    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public Set<String> getTagList() {
        return tagList;
    }

    public void setTagList(Set<String> tagList) {
        this.tagList = tagList;
    }

    public Boolean getBatch() {
        return isBatch;
    }

    public void setBatch(Boolean batch) {
        isBatch = batch;
    }

    public Boolean getOrderly() {
        return isOrderly;
    }

    public void setOrderly(Boolean orderly) {
        isOrderly = orderly;
    }

    public MqConfig getMqConfig() {
        return mqConfig;
    }

    public void setMqConfig(MqConfig mqConfig) {
        this.mqConfig = mqConfig;
    }

    public Integer getConsumeThreadNums() {
        return consumeThreadNums;
    }

    public void setConsumeThreadNums(Integer consumeThreadNums) {
        this.consumeThreadNums = consumeThreadNums;
    }

    public Map<String, RocketMqMessageHandler> getRocketMqMessageHandlerMap() {
        return rocketMqMessageHandlerMap;
    }

    public void setRocketMqMessageHandlerMap(Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap) {
        this.rocketMqMessageHandlerMap = rocketMqMessageHandlerMap;
    }

    public void start(){

        if(isBatch){
            admin = BatchConsumerBeanBuilder.createBatchConsumerBean(mqConfig,this);
        }
        else{
            if(isOrderly){
                admin = OrderConsumerBeanBuilder.createOrderConsumerBean(mqConfig,this);
            }
            else{
                admin  = NormalConsumerBeanBuilder.createNormalConsumerBean(mqConfig,this);
            }
        }

        if(admin != null){

            log.info("启用监听器topic:{},group:{},tag:{}",topic,group,getTags());
            admin.start();
        }
    }

    public void stop(){
        if(admin != null){
            admin.shutdown();
        }
    }

    public String getTags(){
        return String.join("||",tagList);
    }
}
