package com.ygw.ali.rocketmq.vo;

public class Constants {

	public static String PUSH_TEACHING_TOPIC = "Teaching_ID";
	public static Integer PUSH_SUCCESS_CODE = 200;
	public static Integer PUSH_FAILURE_CODE = 500;
}
