package com.ygw.ali.rocketmq.listener.builder;

import com.aliyun.openservices.ons.api.MessageListener;
import com.aliyun.openservices.ons.api.bean.ConsumerBean;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.RocketMqListenerProxy;
import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;

import java.util.HashMap;
import java.util.Map;

public class NormalConsumerBeanBuilder extends ConsumerBeanBuilder {



    public static ConsumerBean createNormalConsumerBean(MqConfig mqConfig, RocketMqListenerProxy proxy){
        ConsumerBean consumerBean = new ConsumerBean();
        consumerBean.setProperties(getProperties(mqConfig,proxy.getGroup(),proxy.getConsumeThreadNums()));
        consumerBean.setSubscriptionTable(getMessageListener(proxy.getTopic(), proxy.getTags(),proxy.getRocketMqMessageHandlerMap()));
        return consumerBean;
    }

    private static Map<Subscription, MessageListener> getMessageListener(String topic, String tag, Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap){
        Map<Subscription, MessageListener> subscriptionMessageTable = new HashMap<>();
        subscriptionMessageTable.put(createSubscription(topic,tag),createRocketMqMessageListenerImpl(rocketMqMessageHandlerMap));
        return subscriptionMessageTable;
    }
}
