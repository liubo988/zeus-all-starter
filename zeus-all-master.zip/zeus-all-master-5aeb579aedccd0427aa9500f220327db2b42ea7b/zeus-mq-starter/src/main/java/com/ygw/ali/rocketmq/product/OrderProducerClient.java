package com.ygw.ali.rocketmq.product;

import java.util.Date;
import java.util.UUID;

import com.aliyun.openservices.shade.com.alibaba.fastjson.JSONObject;
import com.ygw.ali.rocketmq.config.MqConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.bean.OrderProducerBean;
import com.aliyun.openservices.shade.org.apache.commons.lang3.StringUtils;
import com.ygw.ali.rocketmq.vo.Constants;

/**
 * 		
 * <p>Title: OrderProducerClient </p>
 * <p>Description: 顺序消息生产者</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年10月17日 下午2:10:11	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年10月17日 下午2:10:11</p>
 * <p>修改备注：</p>
 */
public class OrderProducerClient {
	private static final Logger logger = LoggerFactory.getLogger(OrderProducerClient.class);

	@Autowired
	private MqConfig mqConfig;

	@Autowired
	private OrderProducerBean orderProducerBean;

	/**
	 * send:顺序消息（FIFO 消息）是消息队列 MQ 提供的一种严格按照顺序来发布和消费的消息。顺序发布和顺序消费是指对于指定的一个 Topic，
	 * 生产者按照一定的先后顺序发布消息；消费者按照既定的先后顺序订阅消息，即先发布的消息一定会先被客户端接收到。
	 * @param topic 主题
	 * @param tag 标签
	 * @param key 业务key
	 * @param body 消息主体
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年10月17日 上午11:04:30
	 */
	public int send(String topic, String tag, String key, Object body) {
		if (StringUtils.isEmpty(topic)) {// 没有订阅默认给双师
			topic = mqConfig.getDefaultTopic();
		}
		Message message =  new Message(topic, tag, key, JSONObject.toJSONBytes(body));
		try {
			SendResult sendResult = orderProducerBean.send(message, UUID.randomUUID().toString());
			if (!ObjectUtils.isEmpty(sendResult)) {
				logger.info(new Date() + " Send mq Ordermessage success. Topic is:{},msgId is :{}", message.getTopic(), sendResult.getMessageId());
			}
		} catch (Exception e) {
			// 消息发送失败，需要进行重试处理，可重新发送这条消息或持久化这条数据进行补偿处理
			logger.info(new Date() + " Send mq message failure. Exception is:{},发送内容:{}", e.getMessage(), message);
			e.printStackTrace();
			return Constants.PUSH_FAILURE_CODE;
		}
		return Constants.PUSH_SUCCESS_CODE;
	}

}
