package com.ygw.ali.rocketmq.product;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.OnExceptionContext;
import com.aliyun.openservices.ons.api.SendCallback;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.aliyun.openservices.shade.com.alibaba.fastjson.JSONObject;
import com.aliyun.openservices.shade.org.apache.commons.lang3.StringUtils;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.vo.Constants;

/**
 * 		
 * <p>Title: ProducerClient </p>
 * <p>Description: 普通消息生产者</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年10月17日 下午2:10:21	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年10月17日 下午2:10:21</p>
 * <p>修改备注：</p>
 */
public class ProducerClient {
	private static final Logger logger = LoggerFactory.getLogger(ProducerClient.class);

	@Autowired
	private MqConfig mqConfig;

	@Autowired
	private ProducerBean producerBean;

	/**
	 * sendMsg:同步发送实体对象消息 可靠同步发送：同步发送是指消息发送方发出数据后，会在收到接收方发回响应之后才发下一个数据包的通讯方式；
	 * 特点：速度快；有结果反馈；数据可靠； 应用场景：应用场景非常广泛，例如重要通知邮件、报名短信通知、营销短信系统等；
	 * @param body 消息主体
	 * @param key 业务key
	 * @param tag 标签
	 * @param topic 主题
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年10月17日 上午11:04:30
	 */
	public int sendMsg(Object body, String key, String tag, String topic) {
		if (StringUtils.isEmpty(tag)) {// 没有订阅默认给双师
			tag = mqConfig.getDefaultTag();
		}
		if (StringUtils.isEmpty(topic)) {// 没有订阅默认给双师
			topic = mqConfig.getDefaultTopic();
		}
		String messageBody = JSONObject.toJSONString(body);
		Message message = new Message(topic, tag, key, messageBody.getBytes(StandardCharsets.UTF_8));
		try {
			SendResult sendResult = producerBean.send(message);
			if (!ObjectUtils.isEmpty(sendResult)) {
				logger.info("发送mq消息成功. Topic is:{},msgId is :{},messageBody={}", message.getTopic(), sendResult.getMessageId(), messageBody);
			}
		} catch (Exception e) {
			// 消息发送失败，需要进行重试处理，可重新发送这条消息或持久化这条数据进行补偿处理
			logger.info(new Date() + " Send mq message failure. Exception is:{},发送内容:{}", e.getMessage(), message);
			e.printStackTrace();
			return Constants.PUSH_FAILURE_CODE;
		}
		return Constants.PUSH_SUCCESS_CODE;
	}



	/**
	 * sendDeliverMsg:同步发送实体对象消息 可靠同步发送：同步发送是指消息发送方发出数据后，会在收到接收方发回响应之后才发下一个数据包的通讯方式；
	 * 特点：速度快；有结果反馈；数据可靠； 应用场景：应用场景非常广泛，例如重要通知邮件、报名短信通知、营销短信系统等；
	 * @param body 消息主体
	 * @param key 业务key
	 * @param tag 标签
	 * @param topic 主题
	 * @param deliverTime 指定具体的延迟时间,long类型
	 * @return
	 * @exception
	 * @author bobo
	 * @date 2019年10月17日 上午11:04:30
	 */
	public int sendDeliverMsg(Object body, String key, String tag, String topic,Long deliverTime) {
		if (StringUtils.isEmpty(tag)) {// 没有订阅默认给双师
			tag = mqConfig.getDefaultTag();
		}
		if (StringUtils.isEmpty(topic)) {// 没有订阅默认给双师
			topic = mqConfig.getDefaultTopic();
		}
		String messageBody = JSONObject.toJSONString(body);
		Message message = new Message(topic, tag, key, messageBody.getBytes(StandardCharsets.UTF_8));
		//放入延迟时间
		message.setStartDeliverTime(deliverTime);
		try {
			SendResult sendResult = producerBean.send(message);
			if (!ObjectUtils.isEmpty(sendResult)) {
				logger.info("发送延迟mq消息成功. Topic is:{},msgId is :{},messageBody={}，延迟具体时间:{}", message.getTopic(), sendResult.getMessageId(), messageBody,deliverTime);
			}
		} catch (Exception e) {
			// 消息发送失败，需要进行重试处理，可重新发送这条消息或持久化这条数据进行补偿处理
			logger.info(new Date() + " Send mq message failure. Exception is:{},发送内容:{}", e.getMessage(), message);
			e.printStackTrace();
			return Constants.PUSH_FAILURE_CODE;
		}
		return Constants.PUSH_SUCCESS_CODE;
	}

	/**
	 * 
	 * sendMsg：发送普通消息
	 * @param body 内容
	 * @param key 唯一业务标识
	 * @param tag 标签
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年11月7日 下午12:54:04
	 */
	public int sendMsg(Object body, String key, String tag) {
		return this.sendMsg(body, key, tag, mqConfig.getDefaultTopic());
	}

	public int sendMsg(Object body, String key) {
		return this.sendMsg(body, key, mqConfig.getDefaultTag(), mqConfig.getDefaultTopic());
	}

	public int sendDeliverMsg(Object body, String key,long deliverTime) {
		return this.sendDeliverMsg(body, key, mqConfig.getDefaultTag(), mqConfig.getDefaultTopic(),deliverTime);
	}

	/**
	 * sendMsgAsy：异步发送消息 可靠异步发送：发送方发出数据后，不等接收方发回响应，接着发送下个数据包的通讯方式； 特点：速度快；有结果反馈；数据可靠；
	 * 应用场景：异步发送一般用于链路耗时较长,对 rt响应时间较为敏感的业务场景,例如用户视频上传后通知启动转码服务,转码完成后通知推送转码结果等；
	 * @param body 消息主体
	 * @param key 业务key
	 * @param tag 标签
	 * @param topic 主题
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年10月17日 上午11:04:58
	 */
	public boolean sendMsgAsy(Object body, String key, String tag, String topic) {
		if (StringUtils.isEmpty(tag)) {// 没有订阅默认给双师
			tag = mqConfig.getDefaultTag();
		}
		if (StringUtils.isEmpty(topic)) {// 没有订阅默认给双师
			topic = mqConfig.getDefaultTopic();
		}
		Long startTime = System.currentTimeMillis();
		String messageBody = JSONObject.toJSONString(body);
		Message message = new Message(topic, tag, key, messageBody.getBytes(StandardCharsets.UTF_8));
		producerBean.sendAsync(message, new SendCallback() {
			@Override
			public void onSuccess(SendResult sendResult) {
				// /消息发送成功
				logger.info("send message success. topic:{},messageId:{}", sendResult.getTopic(), sendResult.getMessageId());
			}

			@Override
			public void onException(OnExceptionContext context) {
				// 消息发送失败
				logger.info("send message failed. exception=" + context.getException());
			}
		});
		Long endTime = System.currentTimeMillis();
		logger.info("单次生产耗时：" + (endTime - startTime) / 1000);
		return true;
	}

	/**
	 * sendMsgAsy：异步发送消息 可靠异步发送：发送方发出数据后，不等接收方发回响应，接着发送下个数据包的通讯方式； 特点：速度快；有结果反馈；数据可靠；
	 * 应用场景：异步发送一般用于链路耗时较长,对 rt响应时间较为敏感的业务场景,例如用户视频上传后通知启动转码服务,转码完成后通知推送转码结果等；
	 * @param body 消息主体
	 * @param key 业务key
	 * @param tag 标签
	 * @return
	 */
	public boolean sendMsgAsy(Object body, String key, String tag) {
		return this.sendMsgAsy(body, key, tag, mqConfig.getDefaultTopic());
	}

	/**
	 * sendMsgAsy：异步发送消息 可靠异步发送：发送方发出数据后，不等接收方发回响应，接着发送下个数据包的通讯方式； 特点：速度快；有结果反馈；数据可靠；
	 * 应用场景：异步发送一般用于链路耗时较长,对 rt响应时间较为敏感的业务场景,例如用户视频上传后通知启动转码服务,转码完成后通知推送转码结果等；
	 * @param body 消息主体
	 * @param key 业务key
	 * @return
	 */
	public boolean sendMsgAsy(Object body, String key) {
		return this.sendMsgAsy(body, key, mqConfig.getDefaultTag(), mqConfig.getDefaultTopic());
	}

	/**
	 * sendMsgOneway：单向发送 单向发送：只负责发送消息，不等待服务器回应且没有回调函数触发，即只发送请求不等待应答；此方式发送消息的过程耗时非常短，一般在微秒级别；
	 * 特点：速度最快，耗时非常短，毫秒级别；无结果反馈；数据不可靠，可能会丢失；
	 * 应用场景：适用于某些耗时非常短，但对可靠性要求并不高的场景，例如日志收集；
	 * @param tag 标签
	 * @param body 消息主体
	 * @param key 业务key
	 * @param tag 标签
	 * @param topic 主题
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2019年10月17日 上午11:05:23
	 */
	public boolean sendMsgOneWay(Object body, String key, String tag, String topic) {
		if (StringUtils.isEmpty(topic)) {// 没有订阅默认给双师
			topic = mqConfig.getDefaultTopic();
		}
		Message message = new Message(topic, tag, key, JSONObject.toJSONBytes(body));
		producerBean.sendOneway(message);
		return true;
	}

}
