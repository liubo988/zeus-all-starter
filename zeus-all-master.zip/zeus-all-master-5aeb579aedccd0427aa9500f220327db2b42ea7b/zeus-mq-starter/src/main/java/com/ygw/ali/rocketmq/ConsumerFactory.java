package com.ygw.ali.rocketmq;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.MethodIntrospector;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ygw.ali.rocketmq.annotation.RocketMQListener;
import com.ygw.ali.rocketmq.annotation.RocketMqListenersContainer;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.RocketMqListenerProxy;
import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;

public class ConsumerFactory implements InitializingBean, ApplicationContextAware {

	private static final Logger log = LoggerFactory.getLogger(ConsumerFactory.class);

	private ApplicationContext context;

	private MqConfig mqConfig;

	private Map<String, RocketMqListenerProxy> rocketMqListenerProxyMap = new HashMap<>();

	@Override
	public void afterPropertiesSet() throws Exception {
		// 初始化所有监听器
		initListener();
		// 启动所有的消费者监听器;
		startConsumerListener();
	}

	public void setMqConfig(MqConfig mqConfig) {
		this.mqConfig = mqConfig;
	}

	private void startConsumerListener() {
		rocketMqListenerProxyMap.forEach((topic, proxy) -> {
			proxy.start();

		});
	}

	@PreDestroy
	private void destroy() {
		rocketMqListenerProxyMap.forEach((topic, proxy) -> {
			proxy.stop();
		});
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
	}

	/**
	 * 
	 * initListener：初始化所有监听器
	 * @exception	
	 * @author bobo
	 * @date 2020年2月13日 下午3:07:44
	 */
	void initListener() {
		// 获取自定义注解：mq监听器容器，如果没有返回
		Map<String, Object> listenersMap = context.getBeansWithAnnotation(RocketMqListenersContainer.class);
		if (CollectionUtils.isEmpty(listenersMap)) {
			log.warn("RocketListeners 没有配置");
			return;
		}

		listenersMap.forEach((beanName, obj) -> {// 遍历自定义mq容器类，查找包含RocketMQListener注解的方法，如果同一个mq容器类有多个此注解方法，则合并注解到第一个。
					Map<Method, RocketMQListener> annotatedMethods = MethodIntrospector.selectMethods(obj.getClass(),
							(MethodIntrospector.MetadataLookup<RocketMQListener>) method -> AnnotatedElementUtils.findMergedAnnotation(method,
									RocketMQListener.class));
					// 初始化自定义消费者监听器。
				initConsumeListener(annotatedMethods, obj);
			});
	}

	private void initConsumeListener(Map<Method, RocketMQListener> annotatedMethod, Object target) {
		if (!CollectionUtils.isEmpty(annotatedMethod)) {// 判断是否有RocketMQListener注解的方法，没有返回;
			annotatedMethod.forEach((method, listener) -> {// 遍历RocketMQListener注解的方法，通过反射机制获取自定义mq处理对象：RocketMqMessageHandler（转义阿里云返回的消息体方法）
						try {
							Object handler = method.invoke(target);
							// 把注解方法返回对象监听器加入到处理监听器中。
							this.addHandlerToListener((RocketMqMessageHandler) handler, listener);
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						}
					});

		} else {
			log.warn("没有rocketmq监听器");
		}

	}

	/**
	 * 
	 * addHandlerToListener：把返回方法对象的消息内容组装放入自定义监听器中
	 * @param handler 消息体方法转义处理对象
	 * @param listener 自定义监听器
	 * @exception	
	 * @author bobo
	 * @date 2020年2月13日 下午3:17:46
	 */
	private void addHandlerToListener(RocketMqMessageHandler handler, RocketMQListener listener) {
		// 读取配置文件中的默认监听的主题，消费组，标签，如果配置文件不存在，则读取自定义监听器上的内容
		String topic = replaceIfNotEmpty(mqConfig.getDefaultTopic(), listener.topic());
		String group = replaceIfNotEmpty(mqConfig.getDefaultGroup(), listener.group());
		String tag = replaceIfNotEmpty(mqConfig.getDefaultTag(), listener.tag());

		if (StringUtils.isEmpty(topic) || StringUtils.isEmpty(group) || StringUtils.isEmpty(tag)) {
			log.warn("自定义监听器方法：RocketMQListener 不存在top或group或tag");
			return;
		}
		// 获取监听器类型:顺序的，批量的，常规的
		Boolean orderly = listener.orderly();
		Boolean batch = listener.batch();
		Integer consumeThreadNums = listener.consumeThreadNums();

		RocketMqListenerProxy proxy = rocketMqListenerProxyMap.get(topic);
		// 封装监听器代理map对象,后面监听全部靠它。
		if (proxy == null) {
			proxy = new RocketMqListenerProxy();
			proxy.setBatch(batch);
			proxy.setConsumeThreadNums(consumeThreadNums);
			proxy.setGroup(group);
			proxy.setMqConfig(mqConfig);
			proxy.setOrderly(orderly);
			proxy.setRocketMqMessageHandlerMap(new HashMap<>());
			proxy.setTagList(new HashSet<>());
			proxy.setTopic(topic);
			// 把封装好的代理对象放入代理对象map中。key为订阅主题,value为代理对象
			rocketMqListenerProxyMap.put(topic, proxy);
		}
		// 每个监听器代理对象放入当前监听器的消息内容,key为消息key，value为自定义RocketMqMessageHandler对象
		proxy.getRocketMqMessageHandlerMap().put(listener.key(), handler);
		// 把监听器的tag放入代理对象的tag集合中
		proxy.getTagList().add(tag);
		return;
	}

	private String replaceIfNotEmpty(String value, String newValue) {
		if (!StringUtils.isEmpty(newValue)) {
			value = newValue;
		}

		return value;
	}
}
