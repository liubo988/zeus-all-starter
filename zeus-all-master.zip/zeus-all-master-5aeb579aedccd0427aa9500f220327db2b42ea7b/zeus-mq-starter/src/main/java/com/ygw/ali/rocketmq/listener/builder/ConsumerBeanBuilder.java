package com.ygw.ali.rocketmq.listener.builder;

import com.aliyun.openservices.ons.api.PropertyKeyConst;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;
import com.ygw.ali.rocketmq.listener.RocketMqMessageListenerImpl;

import java.util.Map;
import java.util.Properties;

public class ConsumerBeanBuilder {

    protected static Properties getProperties(MqConfig mqConfig,String group,Integer consumeThreadNums){
        Properties properties = mqConfig.getMqProperties();
        properties.setProperty(PropertyKeyConst.GROUP_ID, group);
        properties.setProperty(PropertyKeyConst.ConsumeThreadNums, consumeThreadNums + "");
        return properties;
    }

    protected static RocketMqMessageListenerImpl createRocketMqMessageListenerImpl(Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap){
        RocketMqMessageListenerImpl rocketMqMessageListener = new RocketMqMessageListenerImpl();
        rocketMqMessageListener.setRocketMqMessageHandlerMap(rocketMqMessageHandlerMap);
        return rocketMqMessageListener;
    }

    protected static Subscription createSubscription(String topic,String tag){
        Subscription subscription = new Subscription();
        subscription.setTopic(topic);
        subscription.setExpression(tag);
        return subscription;
    }
}
