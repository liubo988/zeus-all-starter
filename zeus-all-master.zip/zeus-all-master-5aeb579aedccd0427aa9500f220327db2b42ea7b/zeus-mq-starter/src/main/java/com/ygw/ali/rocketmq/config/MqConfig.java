package com.ygw.ali.rocketmq.config;

import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.aliyun.openservices.ons.api.PropertyKeyConst;

@ConfigurationProperties(prefix = "ali.rocketmq")
public class MqConfig {
	private String accessKey = "LTAI8EcDFH1mrB5q";
	private String secretKey = "YEKSGfIJRW88ijHXKmVkwr03GGYZVn";
	private String nameSrvAddr = "http://MQ_INST_1026827146553176_BbEyBy4s.mq-internet-access.mq-internet.aliyuncs.com:80";
	private Integer maxReconsumeTimes = 3;

	private String defaultTopic = "Teaching_ID";

	private String defaultGroup = "GID_Teaching";

	private String defaultTag = "default";

	public Properties getMqProperties() {
		Properties properties = new Properties();
		properties.setProperty(PropertyKeyConst.AccessKey, this.accessKey);
		properties.setProperty(PropertyKeyConst.SecretKey, this.secretKey);
		properties.setProperty(PropertyKeyConst.NAMESRV_ADDR, this.nameSrvAddr);
		properties.setProperty(PropertyKeyConst.MaxReconsumeTimes, this.maxReconsumeTimes + "");
		return properties;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getNameSrvAddr() {
		return nameSrvAddr;
	}

	public void setNameSrvAddr(String nameSrvAddr) {
		this.nameSrvAddr = nameSrvAddr;
	}

	public Integer getMaxReconsumeTimes() {
		return maxReconsumeTimes;
	}

	public void setMaxReconsumeTimes(Integer maxReconsumeTimes) {
		this.maxReconsumeTimes = maxReconsumeTimes;
	}

	public String getDefaultTopic() {
		return defaultTopic;
	}

	public void setDefaultTopic(String defaultTopic) {
		this.defaultTopic = defaultTopic;
	}

	public String getDefaultGroup() {
		return defaultGroup;
	}

	public void setDefaultGroup(String defaultGroup) {
		this.defaultGroup = defaultGroup;
	}

	public String getDefaultTag() {
		return defaultTag;
	}

	public void setDefaultTag(String defaultTag) {
		this.defaultTag = defaultTag;
	}
}
