package com.ygw.ali.rocketmq.vo;

import java.io.Serializable;

/**
 * 		
 * <p>Title: MessageVO </p>
 * <p>Description: 消息VO</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年10月17日 上午9:42:48	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年10月17日 上午9:42:48</p>
 * <p>修改备注：</p>
 */
public class MessageVO implements Serializable {

	/**
	 * serialVersionUID: （一句话描述这个变量表示什么）
	 */

	private static final long serialVersionUID = -4168048599612968446L;

	/**
	 * 阿里云返回的消息对象ID;
	 */
	private String messageId;
	/**
	 * 发送的标签名称
	 */
	private String tag;
	/**
	 * 发送的消息内容
	 */
	private String msg;

	/**
	 * 发送的业务key
	 */
	private String key;

	/**
	 * 发送的订阅主题
	 */
	private String topic;

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}
}
