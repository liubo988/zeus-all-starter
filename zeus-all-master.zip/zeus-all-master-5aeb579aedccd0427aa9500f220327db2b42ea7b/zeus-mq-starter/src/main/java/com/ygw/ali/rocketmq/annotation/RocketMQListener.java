package com.ygw.ali.rocketmq.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 改注解运用在消费端的方法上，用来处理同一topic中不同的tag类型的消息
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RocketMQListener {
	/**
	 * 正常的
	 */
	boolean normal() default true;

	/**
	 * 顺序的
	 */
	boolean orderly() default false;

	/**
	 * 批量的
	 */
	boolean batch() default false;

	/**
	 * 消费线程数
	 */
	int consumeThreadNums() default 20;

	/**
	 * 业务key
	 * @return
	 */
	String key();

	/**
	 * tag
	 * @return
	 */
	String tag() default "";

	/**
	 * group
	 * @return
	 */
	String group() default "";

	/**
	 * topic
	 * @return
	 */
	String topic() default "";
}
