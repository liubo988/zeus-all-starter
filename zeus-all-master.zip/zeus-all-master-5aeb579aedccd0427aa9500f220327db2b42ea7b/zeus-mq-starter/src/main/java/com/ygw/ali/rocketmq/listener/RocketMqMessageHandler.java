package com.ygw.ali.rocketmq.listener;

/**
 * <p>Title: RocketMqMessageHandler </p>
 * <p>Description: 消息处理器</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author zlp
 * @date 2019年10月22日 下午2:55
 * @version 1.0
 * <p>修改人:zlp </p>
 * <p>修改时间:2019年10月22日 下午2:55</p>
 * <p>修改备注:</p>
 */
public interface RocketMqMessageHandler {

    /**
     * receiveMessage:接收消息
     * @param message
     * @return void
     * @exception
     * @author zlp
     * @date 2019年10月22日 下午2:56
     */
    void receiveMessage(String message);
}
