package com.ygw.ali.rocketmq.listener.builder;

import com.aliyun.openservices.ons.api.batch.BatchMessageListener;
import com.aliyun.openservices.ons.api.bean.BatchConsumerBean;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.RocketMqListenerProxy;
import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;

import java.util.HashMap;
import java.util.Map;

public class BatchConsumerBeanBuilder extends ConsumerBeanBuilder {

    public static BatchConsumerBean createBatchConsumerBean(MqConfig mqConfig,RocketMqListenerProxy proxy){
        BatchConsumerBean batchConsumerBean = new BatchConsumerBean();
        batchConsumerBean.setProperties(getProperties(mqConfig,proxy.getGroup(),proxy.getConsumeThreadNums()));
        batchConsumerBean.setSubscriptionTable(getBatchMessageListener(proxy.getTopic(), proxy.getTags(),proxy.getRocketMqMessageHandlerMap()));
        return batchConsumerBean;
    }

    private static Map<Subscription, BatchMessageListener> getBatchMessageListener(String topic, String tag,Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap){
        Map<Subscription, BatchMessageListener> subscriptionMessageTable = new HashMap<>();
        subscriptionMessageTable.put(createSubscription(topic,tag),createRocketMqMessageListenerImpl(rocketMqMessageHandlerMap));
        return subscriptionMessageTable;
    }
}
