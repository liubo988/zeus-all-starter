package com.ygw.ali.rocketmq.listener.builder;

import com.aliyun.openservices.ons.api.bean.OrderConsumerBean;
import com.aliyun.openservices.ons.api.bean.Subscription;
import com.aliyun.openservices.ons.api.order.MessageOrderListener;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.listener.RocketMqListenerProxy;
import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;

import java.util.HashMap;
import java.util.Map;

public class OrderConsumerBeanBuilder extends ConsumerBeanBuilder {



    public static OrderConsumerBean createOrderConsumerBean(MqConfig mqConfig, RocketMqListenerProxy proxy){
        OrderConsumerBean orderConsumerBean = new OrderConsumerBean();
        orderConsumerBean.setProperties(getProperties(mqConfig,proxy.getGroup(),proxy.getConsumeThreadNums()));
        orderConsumerBean.setSubscriptionTable(getOrderMessageListener(proxy.getTopic(), proxy.getTags(),proxy.getRocketMqMessageHandlerMap()));
        return orderConsumerBean;
    }

    private static Map<Subscription, MessageOrderListener> getOrderMessageListener(String topic, String tag, Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap){
        Map<Subscription, MessageOrderListener> subscriptionMessageTable = new HashMap<>();
        subscriptionMessageTable.put(createSubscription(topic,tag),createRocketMqMessageListenerImpl(rocketMqMessageHandlerMap));
        return subscriptionMessageTable;
    }
}
