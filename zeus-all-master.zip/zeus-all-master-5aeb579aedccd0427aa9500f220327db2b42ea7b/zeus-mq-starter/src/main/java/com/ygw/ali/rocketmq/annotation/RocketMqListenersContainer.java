package com.ygw.ali.rocketmq.annotation;

import com.aliyun.openservices.shade.com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * 注解在类上，则这个类会被转换成为一个 DefaultMqPushConsumer
 *
 * @author jolly
 */


@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface RocketMqListenersContainer {
}
