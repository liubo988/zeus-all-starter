package com.ygw.ali.rocketmq.autoconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import com.aliyun.openservices.ons.api.bean.OrderProducerBean;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.ygw.ali.rocketmq.ConsumerFactory;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.product.OrderProducerClient;
import com.ygw.ali.rocketmq.product.ProducerClient;

/**
 *
 */
@Configuration
@EnableConfigurationProperties(MqConfig.class)
@ConditionalOnProperty(prefix = "ali.rocketmq", value = "enabled", matchIfMissing = true)
public class RocketAutoConfiguration {

	@Autowired
	private MqConfig mqConfig;

	@Bean
	@ConditionalOnMissingBean(ConsumerFactory.class)
	ConsumerFactory rocketMqConsumerFactory() {
		ConsumerFactory consumerFactory = new ConsumerFactory();
		consumerFactory.setMqConfig(mqConfig);
		return consumerFactory;
	}

	@Bean(initMethod = "start", destroyMethod = "shutdown")
	ProducerBean rocketMqProducerBean() {
		ProducerBean producer = new ProducerBean();
		producer.setProperties(mqConfig.getMqProperties());
		return producer;
	}

	@Bean
	@DependsOn({ "rocketMqProducerBean" })
	@ConditionalOnMissingBean(ProducerClient.class)
	ProducerClient rocketMqProductClient() {
		ProducerClient producerClient = new ProducerClient();
		return producerClient;
	}

	@Bean(initMethod = "start", destroyMethod = "shutdown")
	OrderProducerBean rocketMqOrderProducerBean() {
		OrderProducerBean orderProducerBean = new OrderProducerBean();
		orderProducerBean.setProperties(mqConfig.getMqProperties());
		return orderProducerBean;
	}

	@Bean
	@DependsOn({ "rocketMqOrderProducerBean" })
	@ConditionalOnMissingBean(ProducerClient.class)
	OrderProducerClient rocketMqOrderProducerClient() {
		OrderProducerClient orderProducerClient = new OrderProducerClient();
		return orderProducerClient;
	}
}
