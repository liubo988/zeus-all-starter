package com.ygw.ali.rocketmq.listener;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aliyun.openservices.shade.com.alibaba.fastjson.JSONObject;
import com.aliyun.openservices.shade.org.apache.commons.lang3.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.aliyun.openservices.ons.api.Action;
import com.aliyun.openservices.ons.api.ConsumeContext;
import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.MessageListener;
import com.aliyun.openservices.ons.api.batch.BatchMessageListener;
import com.aliyun.openservices.ons.api.order.ConsumeOrderContext;
import com.aliyun.openservices.ons.api.order.MessageOrderListener;
import com.aliyun.openservices.ons.api.order.OrderAction;
import org.springframework.util.StringUtils;

public class RocketMqMessageListenerImpl implements MessageListener, MessageOrderListener, BatchMessageListener{



	private Map<String,RocketMqMessageHandler> rocketMqMessageHandlerMap = new HashMap<>();



	public void addRocketMqMessageHandler(String key, RocketMqMessageHandler rocketMqMessageHandler) {
		rocketMqMessageHandlerMap.put(key,rocketMqMessageHandler);
	}

	public void setRocketMqMessageHandlerMap(Map<String, RocketMqMessageHandler> rocketMqMessageHandlerMap) {
		this.rocketMqMessageHandlerMap = rocketMqMessageHandlerMap;
	}

	public RocketMqMessageListenerImpl() {

	}


	private static final Logger log = LoggerFactory.getLogger(RocketMqMessageListenerImpl.class);


	private String getStringMessage(Message message){
		String stringMessage = new String(message.getBody(), StandardCharsets.UTF_8);
		log.info("接收到消息messageId={},topic={},tag={},key={},body={}", message.getMsgID(), message.getTopic(), message.getTag(), message.getKey(), stringMessage);
		return stringMessage;
	}

	private RocketMqMessageHandler getHandler(Message message){
		String key = message.getKey();
		RocketMqMessageHandler handler = null;
		if(!StringUtils.isEmpty(key)){
			handler = rocketMqMessageHandlerMap.get(key);
		}

		if(handler == null){
			log.error("没有handler，key={}",key);
			handler = new RocketMqMessageHandler() {
				@Override
				public void receiveMessage(String message) {

				}
			};
		}
		return handler;

	}

	private void handleMessage(Message message){
		String stringMessage = this.getStringMessage(message);
		RocketMqMessageHandler handler = this.getHandler(message);
		handler.receiveMessage(stringMessage);
	}

	@Override
	public Action consume(Message message, ConsumeContext context) {
		this.handleMessage(message);
		return Action.CommitMessage;
	}

	@Override
	public Action consume(List<Message> messages, ConsumeContext context) {
		if (!CollectionUtils.isEmpty(messages)) {
			messages.forEach(msg -> {
				this.handleMessage(msg);
			});
		}
		return Action.CommitMessage;
	}

	@Override
	public OrderAction consume(Message message, ConsumeOrderContext context) {
		this.handleMessage(message);
		return OrderAction.Success;
	}

}
