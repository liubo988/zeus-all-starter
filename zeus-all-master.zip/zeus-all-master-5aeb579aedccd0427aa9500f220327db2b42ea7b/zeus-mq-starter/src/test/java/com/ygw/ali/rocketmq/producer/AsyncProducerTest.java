package com.ygw.ali.rocketmq.producer;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.OnExceptionContext;
import com.aliyun.openservices.ons.api.SendCallback;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.aliyun.openservices.ons.api.exception.ONSClientException;
import com.ygw.ali.rocketmq.config.MqConfig;
import com.ygw.ali.rocketmq.product.ProducerClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.Executors;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AsyncProducerTest {

    private static final Logger log = LoggerFactory.getLogger(AsyncProducerTest.class);

    //普通消息的Producer 已经注册到了spring容器中，后面需要使用时可以直接注入到其它类中
    @Autowired
    private ProducerClient producerClient;

    @Autowired
    private MqConfig mqConfig;

    @Test
    public void testSend() {




        //循环发送消息
        for (int i = 0; i < 1; i++) {
            producerClient.sendMsg("hello","test123","test1234");
        }
    }

}
