package com.ygw.ali.rocketmq;

import com.ygw.ali.rocketmq.listener.RocketMqMessageHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ygw.ali.rocketmq.annotation.RocketMQListener;
import com.ygw.ali.rocketmq.annotation.RocketMqListenersContainer;

//@Component
@RocketMqListenersContainer
public class TestNormalMqListeners {

	private static final Logger log = LoggerFactory.getLogger(TestNormalMqListeners.class);

	@RocketMQListener(key="test123",tag = "test1234",normal = true,group = "GID_zzhen")
	public RocketMqMessageHandler messageListener() {
		return new RocketMqMessageHandler() {
			@Override
			public void receiveMessage(String message) {
				log.info("接收到消息:{}", message);
			}
		};
	}
}
