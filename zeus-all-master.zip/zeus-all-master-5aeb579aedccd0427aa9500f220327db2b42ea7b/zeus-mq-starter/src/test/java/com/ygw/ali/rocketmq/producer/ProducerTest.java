package com.ygw.ali.rocketmq.producer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ygw.ali.rocketmq.product.ProducerClient;
import com.ygw.ali.rocketmq.vo.MessageVO;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProducerTest {

	private static final Logger log = LoggerFactory.getLogger(ProducerTest.class);

	// 普通消息的Producer 已经注册到了spring容器中，后面需要使用时可以直接注入到其它类中
	@Autowired
	private ProducerClient producerClient;

	@Test
	public void testSend() {

		// 循环发送消息
		for (int i = 0; i < 1; i++) {
			MessageVO message = new MessageVO();
			message.setTag("test");
			message.setMsg("啦啦啦啦" + i);
			int resultCode = producerClient.sendMsg("test", "112222");
			if (resultCode == 200) {
				System.out.println("发送成功");
			}

		}
	}

}
