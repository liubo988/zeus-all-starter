//package com.ygw.ali.rocketmq;
//
//import com.aliyun.openservices.ons.api.Message;
//import com.aliyun.openservices.ons.api.order.ConsumeOrderContext;
//import com.aliyun.openservices.ons.api.order.MessageOrderListener;
//import com.aliyun.openservices.ons.api.order.OrderAction;
//import com.ygw.ali.rocketmq.annotation.RocketMqListenersContainer;
//import com.ygw.ali.rocketmq.annotation.RocketMQListener;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
////@Component
//@RocketMqListenersContainer
//public class TestOrderMqListeners {
//    private static final Logger log = LoggerFactory.getLogger(TestOrderMqListeners.class);
//
//    @RocketMQListener(tag = "test")
//    public MessageOrderListener messageOrderListener(){
//        return new MessageOrderListener() {
//            @Override
//            public OrderAction consume(Message message, ConsumeOrderContext consumeOrderContext) {
//                log.info("接收到顺序消息{}",message);
//                return OrderAction.Success;
//            }
//        };
//    }
//}
