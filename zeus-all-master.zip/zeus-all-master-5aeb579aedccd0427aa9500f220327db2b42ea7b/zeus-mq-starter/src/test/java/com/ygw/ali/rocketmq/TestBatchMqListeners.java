//package com.ygw.ali.rocketmq;
//
//import com.aliyun.openservices.ons.api.Action;
//import com.aliyun.openservices.ons.api.ConsumeContext;
//import com.aliyun.openservices.ons.api.Message;
//import com.aliyun.openservices.ons.api.batch.BatchMessageListener;
//import com.ygw.ali.rocketmq.annotation.RocketMqListenersContainer;
//import com.ygw.ali.rocketmq.annotation.RocketMQListener;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.util.CollectionUtils;
//
//import java.util.List;
//
////@Component
//@RocketMqListenersContainer
//public class TestBatchMqListeners {
//
//    private static final Logger log = LoggerFactory.getLogger(TestBatchMqListeners.class);
//
//    @RocketMQListener(tag = "test")
//    public BatchMessageListener batchMessageListener(){
//
//        return new BatchMessageListener() {
//            @Override
//            public Action consume(List<Message> list, ConsumeContext consumeContext) {
//                log.info("接收到批消息长度{}",list.size());
//
//                if(!CollectionUtils.isEmpty(list)){
//                    list.forEach(message -> {
//                        log.info("消息详情:{}",message);
//                    });
//                }
//
//                return Action.CommitMessage;
//            }
//        };
//    }
//}
