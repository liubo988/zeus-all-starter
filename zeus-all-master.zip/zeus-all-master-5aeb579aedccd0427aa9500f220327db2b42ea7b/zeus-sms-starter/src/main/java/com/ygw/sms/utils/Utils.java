package com.ygw.sms.utils;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import com.aliyuncs.CommonResponse;
import com.google.gson.Gson;
import com.ygw.sms.exception.SmsException;
import com.ygw.sms.template.BatchSmsTemplate;
import com.ygw.sms.template.SmsTemplate;

/**
 * 		
 * <p>Title: Utils </p>
 * <p>Description: 工具类，内部使用</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年11月11日 下午1:52:21	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年11月11日 下午1:52:21</p>
 * <p>修改备注：</p>
 */
public class Utils {

	private static final String SUCCESS_CODE = "OK";
	/**
	 * 宽松校验即可.
	 */
	private static final String PHONE_NUMBER_REGEX = "\\d{5,}";

	/**
	 * 生成4位数随机验证码.
	 *
	 * @return 随机数
	 */
	public static int randomCode() {
		return 100_0 + ThreadLocalRandom.current().nextInt(1_000_0 - 100_0);
	}

	/**
	 * Map 转 json 字符串的简单实现.
	 *
	 * @param map the map
	 *
	 * @return the json string
	 */
	public static String toJsonStr(final Map<String, String> map) {
		if (null == map || map.isEmpty()) {
			return null;
		}

		final StringBuilder sb = new StringBuilder();
		sb.append('{');
		for (final Map.Entry<String, String> entry : map.entrySet()) {
			sb.append('"').append(entry.getKey().replace("\"", "\\\"")).append('"').append(':').append('"')
					.append(entry.getValue().replace("\"", "\\\"")).append('"').append(',');
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append('}');
		return sb.toString();
	}

	/**
	 * 校验 SmsTemplate.
	 *
	 * @param template the SmsTemplate
	 */
	public static void checkSmsTemplate(final SmsTemplate template) {

		checkNotEmpty(template.getSignName(), "SmsTemplate signName must be not empty");
		checkNotEmpty(template.getTemplateCode(), "SmsTemplate templateCode must be not empty");
		checkNotEmpty(template.getPhoneNumbers(), "SmsTemplate phoneNumbers must be not empty");

	}

	/**
	 * 校验 BatchSmsTemplate.
	 *
	 * @param template the BatchSmsTemplate
	 */
	public static void checkBatchSmsTemplate(final BatchSmsTemplate template) {

		checkNotEmpty(template.getSignNames(), "BatchSmsTemplate signNames must be not empty");
		checkNotEmpty(template.getPhoneNumbers(), "BatchSmsTemplate phoneNumbers must be not empty");
		checkNotEmpty(template.getTemplateCode(), "BatchSmsTemplate templateCode must be not empty");
		checkNotEmpty(template.getTemplateParams(), "BatchSmsTemplate templateParams must be not empty");

		if (template.getSignNames().size() != template.getPhoneNumbers().size()
				&& template.getPhoneNumbers().size() != template.getTemplateParams().size()) {
			throw new IllegalArgumentException("BatchSmsTemplate phoneNumbers, signNames, templateParams size must be the same");
		}
	}

	/**
	 * 校验 SendSmsResponse 状态.
	 *
	 * @param response the SendSmsResponse
	 */
	public static void checkSmsResponse(final CommonResponse response) {
		if (null == response) {
			throw new SmsException("Response is null");
		}
		final Gson gson = new Gson();
		final Map<String, String> json = gson.fromJson(response.getData(), Map.class);
		if (!SUCCESS_CODE.equalsIgnoreCase(json.get("Code"))) {
			throw new SmsException("Http status: " + response.getHttpStatus() + ", response: " + response.getData());
		}
	}

	/**
	 * 校验手机号码（中国）.
	 *
	 * @param phoneNumber the phone number
	 */
	public static void checkPhoneNumber(final String phoneNumber) {
		if (null == phoneNumber || !phoneNumber.matches(PHONE_NUMBER_REGEX)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
	}

	/**
	 * 校验字符串不为空.
	 *
	 * @param str the str
	 * @param message the message
	 */
	public static void checkNotEmpty(final String str, final String message) {
		if (null == str || str.isEmpty()) {
			throw new IllegalArgumentException(message);
		}
	}

	/**
	 * 校验集合不为空.
	 *
	 * @param coll the Collection
	 * @param message the message
	 */
	static void checkNotEmpty(final Collection coll, final String message) {
		if (null == coll || coll.isEmpty()) {
			throw new IllegalArgumentException(message);
		}
	}
}
