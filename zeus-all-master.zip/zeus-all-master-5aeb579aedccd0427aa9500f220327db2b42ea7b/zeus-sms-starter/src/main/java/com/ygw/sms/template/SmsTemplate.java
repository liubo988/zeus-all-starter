package com.ygw.sms.template;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 		
 * <p>Title: SmsTemplate </p>
 * <p>Description: 阿里云sms短信模板</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年11月11日 下午1:53:01	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年11月11日 下午1:53:01</p>
 * <p>修改备注：</p>
 */
@Builder(builderClassName = "Builder", toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SmsTemplate {
	private String signName;
	private String templateCode;
	private Map<String, String> templateParam;
	private List<String> phoneNumbers;

	public static class Builder {
		/**
		 * 添加短信模板参数.
		 *
		 * @param key the key
		 * @param value the value
		 *
		 * @return this
		 */
		public Builder addTemplateParam(final String key, final String value) {
			if (null == this.templateParam) {
				this.templateParam = new HashMap<>(3);
			}

			this.templateParam.put(key, value);
			return this;
		}
	}
}
