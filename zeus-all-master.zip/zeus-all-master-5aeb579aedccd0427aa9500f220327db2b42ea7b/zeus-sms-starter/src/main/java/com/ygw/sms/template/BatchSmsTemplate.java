package com.ygw.sms.template;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 		
 * <p>Title: BatchSmsTemplate </p>
 * <p>Description: 阿里云 SMS 短信模板.</p>
 * <p>Copyright (c) 2019 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2019年11月11日 下午1:52:46	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2019年11月11日 下午1:52:46</p>
 * <p>修改备注：</p>
 */
@Builder(builderClassName = "Builder", toBuilder = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BatchSmsTemplate {
	private List<String> signNames;
	private String templateCode;
	private List<Map<String, String>> templateParams;
	private List<String> phoneNumbers;
}
